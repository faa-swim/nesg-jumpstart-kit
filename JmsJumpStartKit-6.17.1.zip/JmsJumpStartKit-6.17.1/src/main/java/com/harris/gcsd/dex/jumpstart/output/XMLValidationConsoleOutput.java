/*******************************************************************************
 * Copyright (c) 2021 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jumpstart.output;

import com.harris.gcsd.dex.jumpstart.GenericMessage;

//For schema validation
import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Validator;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.StringReader;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

/**
* Outputs message details to the console.
*/
public class XMLValidationConsoleOutput implements Output
{

    private Validator theValidator;
    private static AtomicInteger theValidCount = new AtomicInteger();
    private static AtomicInteger theInvalidCount = new AtomicInteger();

    /**
     * Constructs a console output with the provided file.
     *
     * @param aSchemaPath the path to the schema file to use
     * @throws SAXException if the validation schema could not be set
     */
    public XMLValidationConsoleOutput(String aSchemaPath) throws SAXException
    {
        File schemaFile = new File(aSchemaPath);
        SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        try
        {
            Schema schema = schemaFactory.newSchema(schemaFile);
            theValidator = schema.newValidator();
        }
        catch (SAXException e)
        {
            throw new SAXException("Unable to set schema validation: " + e.getMessage());
        }
    }

    @Override
    public void onMessage(GenericMessage aMessage)
    {
        Object content = aMessage.getContent();
        if (content instanceof String)
        {
            try
            {
                synchronized (theValidator)
                {
                    theValidator.validate(new StreamSource(new StringReader((String) content)));
                }
                System.out.println("XML Validation: Message IS valid");
                theValidCount.getAndIncrement();
            }
            catch (SAXException e)
            {
                System.out.println("XML Validation: Message IS NOT valid");
                System.out.println(e.getMessage());
                theInvalidCount.getAndIncrement();
            }
            catch (IOException e)
            {
                System.out.println("XML Validation: Error reading message body");
                System.out.println(e.getMessage());
            }
        }
        else
        {
            System.out.println("Unsupported message type for xml validation: " + aMessage.getClass().getName());
        }
    }

    @Override
    public void finalOutput()
    {
        System.out.println("Total valid messages: " + theValidCount.get());
        System.out.println("Total invalid messages: " + theInvalidCount.get());
        System.out.println("");
    }
}
