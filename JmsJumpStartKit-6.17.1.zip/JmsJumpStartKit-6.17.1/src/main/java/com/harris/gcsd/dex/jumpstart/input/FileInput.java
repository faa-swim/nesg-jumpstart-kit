/*******************************************************************************
 * Copyright (c) 2021 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jumpstart.input;

import com.harris.gcsd.dex.jumpstart.FileUtil;
import com.harris.gcsd.dex.jumpstart.GenericMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicLong;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.stream.Collectors;


/**
 * File input that loads property and content files from a directory. Each property and corresponding content file must
 * be named the same. The properties file contains the message headers in java properties format and must have a
 * file extension of .properties. Text content files can have an extension of either .xml for XML content or .txt for
 * non XML text content. Binary content files must have a file extension of .bytes. If the content file is not present
 * the message content will be null.
 */
public class FileInput implements Input
{
    // Temporarily commented out due to conflicts with the solace topic producer
    //private static final List<String> KEYS_TO_REMOVE = Arrays.asList("DEX_SOURCE_TYPE", "DEX_SOURCE_NODE",
    //      "solace_routing_dest_name", "JMS_Solace_isXML", "JMS_Solace_DeliverToOne", "JMS_Solace_ElidingEligible",
    //      "JMS_Solace_DeadMsgQueueEligible", "breadcrumbId");

    private static final List<String> KEYS_TO_REMOVE = Arrays.asList("");

    private static final Logger theLogger = LoggerFactory.getLogger(FileInput.class);

    private List<GenericMessage> theMessages;
    private AtomicLong theIndex = new AtomicLong();

    /**
     * Constructs a file input with the provided directory.
     *
     * @param aDirectory the directory to read files from
     * @throws FileNotFoundException if no property files are found in the given directory
     */
    public FileInput(File aDirectory) throws FileNotFoundException
    {
        try
        {
            theMessages = loadData(aDirectory);
        }
        catch (FileNotFoundException e)
        {
            throw e;
        }
    }

    @Override
    public GenericMessage next()
    {
        GenericMessage message = theMessages.get((int) (theIndex.getAndIncrement() % theMessages.size()));

        return message;
    }

    /**
     * Loads property and content files from a directory.
     *
     * @param aDirectory the directory containing the files
     * @return the list of ArchiveMessages
     * @throws FileNotFoundException if no property files are found in the given directory
     */
    private List<GenericMessage> loadData(File aDirectory) throws FileNotFoundException
    {
        List<GenericMessage> messages = new ArrayList<>();

        File[] files = aDirectory.listFiles((aDir, aName) -> aName.endsWith(".properties"));

        if (files == null)
        {
            throw new FileNotFoundException("Message directory not found");
        }

        for (File file : Objects.requireNonNull(files))
        {
            try
            {
                Properties props = new Properties();

                try (InputStream is = new FileInputStream(file))
                {
                    props.load(is);
                }

                //Create a map of properties from the properties object.
                Map<String, Object> propMap = props.entrySet().stream().collect(Collectors.toMap(
                    entry -> entry.getKey().toString(), Map.Entry::getValue));

                propMap.keySet().removeAll(KEYS_TO_REMOVE);

                File contentFile = new File(file.getAbsolutePath().replaceAll(".properties", ".xml"));
                if (!contentFile.exists())
                {
                    contentFile = new File(file.getAbsolutePath().replaceAll(".properties", ".txt"));
                }

                if (contentFile.exists())
                {
                    Object content = FileUtil.readText(contentFile);
                    messages.add(new GenericMessage(propMap, content));
                }
                else
                {
                    contentFile = new File(file.getAbsolutePath().replaceAll(".properties", ".bytes"));
                    if (contentFile.exists())
                    {
                        Object content = FileUtil.readBytes(contentFile);
                        messages.add(new GenericMessage(propMap, content));
                    }
                }
            }
            catch (Exception e)
            {
                theLogger.warn("Could not load message related to file: {} due to: {}", file.getAbsoluteFile(),
                    e.getMessage(), e);
            }
        }

        if (messages.size() == 0)
        {
            throw new FileNotFoundException("No property files found when loading the message files");
        }

        return messages;
    }
}
