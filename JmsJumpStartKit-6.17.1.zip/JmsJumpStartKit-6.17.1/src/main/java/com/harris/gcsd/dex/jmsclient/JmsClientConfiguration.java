/*******************************************************************************
 * Copyright (c) 2021 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jmsclient;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


/**
* Configuration for the JMS Client. Typically the configuration is created at program startup. Changes to
* the configuration after program startup may cause unexpected results.
*/
public class JmsClientConfiguration
{
    public static final String AUTH_TYPE_BASIC = "BASIC";
    public static final String AUTH_TYPE_CLIENT_CERTIFICATE = "CLIENT_CERTIFICATE";

    public static final String AUTO_ACKNOWLEDGE = "AUTO_ACKNOWLEDGE";
    public static final String DEFAULT_TRANSACTED = "false";

    public static final String DESTINATION_TYPE_JNDI = "jndi";
    public static final String DESTINATION_TYPE_QUEUE = "queue";
    public static final String DESTINATION_TYPE_TOPIC = "topic";

    private static final int DEFAULT_MAX_CONNECTION_RETRIES = 0;
    private static final int DEFAULT_INTERVAL_BETWEEN_CONNECTION_RETRIES = 1000;
    private static final int DEFAULT_TRANSACTION_LIMIT = -1;

    //Solace specific constants
    private static final String SOLACE_INITIAL_CONTEXT_FACTORY = "com.solacesystems.jndi.SolJNDIInitialContextFactory";
    private static final String SOLACE_JMS_VPN = "Solace_JMS_VPN";

    private static final String SOLACE_JMS_AUTHENTICATION_SCHEME = "Solace_JMS_Authentication_Scheme";
    private static final String AUTHENTICATION_SCHEME_CLIENT_CERTIFICATE = "AUTHENTICATION_SCHEME_CLIENT_CERTIFICATE";
    private static final String SOLACE_JMS_SSL_CONNECTION_DOWNGRADE_TO = "Solace_JMS_SSL_ConnectionDowngradeTo";
    private static final String PLAIN_TEXT = "PLAIN_TEXT";

    private String theContextFactory;
    private String theProviderUrl;
    private Map<String, String> theAdditionalContextParams;

    private String theAckType;
    private boolean theIsTransacted;
    private int theTransactionLimit;

    private String theAuthType;
    private String theUsername;
    private String thePassword;

    private String theConnectionFactory;
    private int theMaxConnectionRetries;
    private int theIntervalBetweenConnectionRetries;

    private String theDestinationType;
    private String theDestinationName;
    private int theDeliveryMode;

    private String theDurableSubscriptionName;
    private String theFormatString;

    /**
     * Constructs a JMS Client Configuration with the default destination type of JNDI.
     */
    public JmsClientConfiguration()
    {
        this.theAuthType = AUTH_TYPE_BASIC;
        this.theAckType = AUTO_ACKNOWLEDGE;
        this.theDestinationType = DESTINATION_TYPE_JNDI;
        this.theMaxConnectionRetries = DEFAULT_MAX_CONNECTION_RETRIES;
        this.theIntervalBetweenConnectionRetries = DEFAULT_INTERVAL_BETWEEN_CONNECTION_RETRIES;
        this.theTransactionLimit = DEFAULT_TRANSACTION_LIMIT;
    }

    /**
     * Constructs a JMS Client Configuration from a properties file.
     *
     * @param aPropertiesFileLocation the location of  the properties file
     */
    public JmsClientConfiguration(String aPropertiesFileLocation)
    {
        try (FileInputStream fileInputStream = new FileInputStream(aPropertiesFileLocation))
        {
            Properties props = new Properties();
            props.load(fileInputStream);

            theAdditionalContextParams = new HashMap<>();

            theContextFactory = props.getProperty("jndi.context.factory");
            theProviderUrl = props.getProperty("jndi.provider.url");

            if (props.getProperty("keystore.file") != null)
            {
                setKeystoreFile(props.getProperty("keystore.file"));
                setKeystorePassword(props.getProperty("keystore.password"));
                setKeystoreType(props.getProperty("keystore.type", "JKS"));
            }

            if (props.getProperty("truststore.file") != null)
            {
                setTruststoreFile(props.getProperty("truststore.file"));

                if (props.getProperty("truststore.password") != null)
                {
                    setTruststorePassword(props.getProperty("truststore.password"));
                }

                setTruststoreType(props.getProperty("truststore.type", "JKS"));
            }

            theAuthType = props.getProperty("auth.type", AUTH_TYPE_BASIC);
            theAckType = props.getProperty("ack.type", AUTO_ACKNOWLEDGE);
            theIsTransacted = Boolean.parseBoolean(props.getProperty("transacted.session", DEFAULT_TRANSACTED));
            theTransactionLimit = Integer.parseInt(props.getProperty("transaction.limit",
                String.valueOf(DEFAULT_TRANSACTION_LIMIT)));
            theUsername = props.getProperty("username");
            thePassword = props.getProperty("password");

            theConnectionFactory = props.getProperty("connection.factory");
            theMaxConnectionRetries = Integer.parseInt(props.getProperty("connection.retry.count",
                String.valueOf(DEFAULT_MAX_CONNECTION_RETRIES)));
            theIntervalBetweenConnectionRetries = Integer.parseInt(props.getProperty("connection.retry.interval",
                String.valueOf(DEFAULT_INTERVAL_BETWEEN_CONNECTION_RETRIES)));

            theDestinationName = props.getProperty("destination.name");
            theDestinationType = props.getProperty("destination.type", DESTINATION_TYPE_JNDI);

            theDurableSubscriptionName = props.getProperty("durable.subscription.name");

            theFormatString = props.getProperty("format.string");

            //Solace specific
            if (SOLACE_INITIAL_CONTEXT_FACTORY.equals(theContextFactory))
            {
                String solaceVpn = props.getProperty("solace.vpn");
                if (solaceVpn != null)
                {
                    theAdditionalContextParams.put(SOLACE_JMS_VPN, solaceVpn);
                }

                if (AUTH_TYPE_CLIENT_CERTIFICATE.equals(theAuthType))
                {
                    theAdditionalContextParams.put(SOLACE_JMS_AUTHENTICATION_SCHEME,
                        AUTHENTICATION_SCHEME_CLIENT_CERTIFICATE);
                }
                String sslDowngrade = props.getProperty("enable.ssl.downgrade");
                if (sslDowngrade != null && (sslDowngrade.toLowerCase()).equals("true"))
                {
                    theAdditionalContextParams.put(SOLACE_JMS_SSL_CONNECTION_DOWNGRADE_TO, PLAIN_TEXT);
                }

            }
        }
        catch (Exception e)
        {
            throw new RuntimeException("Could not load properties: " + e.getMessage(), e);
        }

    }

    public String getContextFactory()
    {
        return theContextFactory;
    }

    public void setContextFactory(String aContextFactory)
    {
        theContextFactory = aContextFactory;
    }

    public String getProviderUrl()
    {
        return theProviderUrl;
    }

    public void setProviderUrl(String aProviderUrl)
    {
        theProviderUrl = aProviderUrl;
    }

    public Map<String, String> getAdditionalContextParams()
    {
        return theAdditionalContextParams;
    }

    public void setAdditionalContextParams(Map<String, String> aAdditionalContextParams)
    {
        theAdditionalContextParams = aAdditionalContextParams;
    }

    /**
     * Gets the javax.net.ssl.keyStore system property.
     *
     * @return the keystore file location or null if it is not set
     */
    public String getKeystoreFile()
    {
        return System.getProperty("javax.net.ssl.keyStore");
    }

    /**
     * Sets the javax.net.ssl.keyStore system property.
     *
     * @param aKeystoreFile the keystore file location
     */
    public void setKeystoreFile(String aKeystoreFile)
    {
        System.setProperty("javax.net.ssl.keyStore", aKeystoreFile);
    }

    /**
     * Gets the javax.net.ssl.keyStorePassword system property.
     *
     * @return the keystore password or null if it is not set
     */
    public String getKeystorePassword()
    {
        return System.getProperty("javax.net.ssl.keyStorePassword");
    }

    /**
     * Sets the javax.net.ssl.keyStorePassword system property.
     *
     * @param aKeystorePassword the keystore password
     */
    public void setKeystorePassword(String aKeystorePassword)
    {
        System.setProperty("javax.net.ssl.keyStorePassword", aKeystorePassword);
    }

    /**
     * Gets the javax.net.ssl.keyStoreType system property.
     *
     * @return the keystore type or null if it is not set
     */
    public String getKeystoreType()
    {
        return System.getProperty("javax.net.ssl.keyStoreType");
    }

    /**
     * Sets the javax.net.ssl.keyStoreType system property.
     *
     * @param aKeystoreType the keystore type
     */
    public void setKeystoreType(String aKeystoreType)
    {
        System.setProperty("javax.net.ssl.keyStoreType", aKeystoreType);
    }

    /**
     * Gets the javax.net.ssl.trustStore system property.
     *
     * @return the truststore file location or null if it is not set
     */
    public String getTruststoreFile()
    {
        return System.getProperty("javax.net.ssl.trustStore");
    }

    /**
     * Sets the javax.net.ssl.trustStore system property.
     *
     * @param aTruststoreFile the truststore file location
     */
    public void setTruststoreFile(String aTruststoreFile)
    {
        System.setProperty("javax.net.ssl.trustStore", aTruststoreFile);
    }

    /**
     * Gets the javax.net.ssl.trustStorePassword system property.
     *
     * @return the truststore password or null if it is not set
     */
    public String getTruststorePassword()
    {
        return System.getProperty("javax.net.ssl.trustStorePassword");
    }

    /**
     * Sets the javax.net.ssl.trustStorePassword system property.
     *
     * @param aTruststorePassword the truststore password
     */
    public void setTruststorePassword(String aTruststorePassword)
    {
        System.setProperty("javax.net.ssl.trustStorePassword", aTruststorePassword);
    }

    /**
     * Gets the javax.net.ssl.trustStoreType system property.
     *
     * @return the truststore type or null if it is not set
     */
    public String getTruststoreType()
    {
        return System.getProperty("javax.net.ssl.trustStoreType");
    }

    /**
     * Sets the javax.net.ssl.trustStoreType system property.
     *
     * @param aTruststoreType the truststore type
     */
    public void setTruststoreType(String aTruststoreType)
    {
        System.setProperty("javax.net.ssl.trustStoreType", aTruststoreType);
    }

    public String getAckType()
    {
        return theAckType;
    }

    public void setAckType(String aAckType)
    {
        theAckType = aAckType;
    }

    public boolean getIsTransacted()
    {
        return theIsTransacted;
    }

    public void setIsTransacted(boolean atheIsTransacted)
    {
        theIsTransacted = atheIsTransacted;
    }

    public int getTransactionLimit()
    {
        return theTransactionLimit;
    }

    public void setTransactionLimit(int aTransactionLimit)
    {
        theTransactionLimit = aTransactionLimit;
    }

    public String getAuthType()
    {
        return theAuthType;
    }

    public void setAuthType(String aAuthType)
    {
        theAuthType = aAuthType;
    }

    public String getUsername()
    {
        return theUsername;
    }

    public void setUsername(String aUsername)
    {
        theUsername = aUsername;
    }

    public String getPassword()
    {
        return thePassword;
    }

    public void setPassword(String aPassword)
    {
        thePassword = aPassword;
    }

    public String getConnectionFactory()
    {
        return theConnectionFactory;
    }

    public void setConnectionFactory(String aConnectionFactory)
    {
        theConnectionFactory = aConnectionFactory;
    }

    public int getMaxConnectionRetries()
    {
        return theMaxConnectionRetries;
    }

    public void setMaxConnectionRetries(int aMaxConnectionRetries)
    {
        theMaxConnectionRetries = aMaxConnectionRetries;
    }

    public int getIntervalBetweenConnectionRetries()
    {
        return theIntervalBetweenConnectionRetries;
    }

    public void setIntervalBetweenConnectionRetries(int aIntervalBetweenConnectionRetries)
    {
        theIntervalBetweenConnectionRetries = aIntervalBetweenConnectionRetries;
    }

    public String getDestinationType()
    {
        return theDestinationType;
    }

    public void setDestinationType(String aDestinationType)
    {
        theDestinationType = aDestinationType;
    }

    public String getDestinationName()
    {
        return theDestinationName;
    }

    public void setDestinationName(String aDestinationName)
    {
        theDestinationName = aDestinationName;
    }

    public int getDeliveryMode()
    {
        return theDeliveryMode;
    }

    public void setDeliveryMode(int aDeliveryMode)
    {
        theDeliveryMode = aDeliveryMode;
    }

    public String getDurableSubscriptionName()
    {
        return theDurableSubscriptionName;
    }

    public void setDurableSubscriptionName(String aDurableSubscriptionName)
    {
        theDurableSubscriptionName = aDurableSubscriptionName;
    }

    /**
     * Checks if the username and password are set.
     *
     * @return true if the credentials are set
     */
    public boolean credentialsSet()
    {
        return getUsername() != null && !("").equals(getUsername()) &&
        getPassword() != null && !("").equals(getPassword());
    }

    /**
     * Checks if the delivery mode.
     *
     * @return true if the delivery mode are set
     */
    public boolean isDeliveryModePersistent()
    {
        return getDeliveryMode() > 1;
    }

    public String getFormatString()
    {
        return theFormatString;
    }

    public void setFormatString(String aFormatString)
    {
        theFormatString = aFormatString;
    }
}
