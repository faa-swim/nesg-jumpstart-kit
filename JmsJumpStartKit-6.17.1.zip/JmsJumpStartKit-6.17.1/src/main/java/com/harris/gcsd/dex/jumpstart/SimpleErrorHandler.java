/*******************************************************************************
 * Copyright (c) 2021 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jumpstart;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class for error handling.
 */
public class SimpleErrorHandler implements ErrorHandler
{

    // The class logger
    private static final Logger theLogger = LoggerFactory.getLogger(SimpleErrorHandler.class);

    private boolean theRecievedError = false;

    /**
     * Getter statement for recieve error variable
     *
     * @return the recieved error message.
     */
    public boolean recievedError()
    {
        return theRecievedError;
    }

    /**
     * Throws a warning if parse fails.
     *
     * @param aError the error message
     * @throws SAXException a general SAX warning
     */
    public void warning(SAXParseException aError) throws SAXException
    {
        theLogger.debug("SAXParseException: ", aError);
    }

    /**
     * Throws an error if parse fails.
     *
     * @param aError the error message
     * @throws SAXException a general SAX error
     */
    public void error(SAXParseException aError) throws SAXException
    {
        theRecievedError = true;
        theLogger.debug("SAXParseException: ", aError);
    }

    /**
     * Throws a fatal error if parse fails.
     *
     * @param aError the error message
     * @throws SAXException a general fatal SAX error
     */
    public void fatalError(SAXParseException aError) throws SAXException
    {
        theRecievedError = true;
        theLogger.debug("SAXParseException: ", aError);
    }
}