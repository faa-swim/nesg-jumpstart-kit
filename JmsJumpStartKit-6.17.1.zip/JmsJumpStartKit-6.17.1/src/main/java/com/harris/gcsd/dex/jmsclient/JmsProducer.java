/*******************************************************************************
 * Copyright (c) 2021 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jmsclient;

import java.util.Enumeration;
import java.util.Map;

import javax.jms.BytesMessage;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.TextMessage;
import javax.naming.NamingException;

/**
* JMS Producer Implementation that supports Text and Bytes messages. This class is not thread safe
* and therefore should not be shared among threads.
*/
public class JmsProducer extends JmsClient
{
    private MessageProducer theMessageProducer;

    /**
     * Constructs a JMS client using the provided JMS Client Configuration.
     *
     * @param aConfiguration the configuration
     */
    public JmsProducer(JmsClientConfiguration aConfiguration)
    {
        super(aConfiguration);
    }

    /**
     * Sends a message to the destination set in the configuration.
     *
     * @param aMessage the message to send
     * @throws JMSException if an exception occurs while sending the message
     */
    public void send(Message aMessage) throws JMSException
    {
        try
        {
            theMessageProducer.send(aMessage);
        }
        catch (JMSException e)
        {
            handleJmsException(e);
            theMessageProducer.send(aMessage);
        }
    }

    /**
     * Sends a message to the destination set in the configuration.
     *
     * @param aMessage the message to send
     * @param aDeliveryMode the delivery mode to use
     * @param aPriority the priority for this message
     * @param aTimeToLive the message's lifetime (in milliseconds)
     * @throws JMSException if an exception occurs while sending the message
     */
    public void send(Message aMessage, int aDeliveryMode, int aPriority, long aTimeToLive) throws JMSException
    {
        try
        {
            theMessageProducer.send(aMessage, aDeliveryMode, aPriority, aTimeToLive);
        }
        catch (JMSException e)
        {
            handleJmsException(e);
            theMessageProducer.send(aMessage, aDeliveryMode, aPriority, aTimeToLive);
        }
    }

    /**
     * Sends a message to the provided destination. The destination is looked up
     * via JNDI (default) or created with createTopic or createQueue based on the
     * destination type specified in the JmsClientConfiguration.
     *
     * @param aDestinationName the name of the destination
     * @param aMessage the message to send
     * @throws NamingException if the destination type is JNDI and the destination is not found
     * @throws JMSException if an exception occurs while sending the message
     */
    public void send(String aDestinationName, Message aMessage)
    throws NamingException, JMSException
    {
        Destination destination = getDestination(aDestinationName);

        try
        {
            theMessageProducer.send(destination, aMessage);
        }
        catch (JMSException e)
        {
            handleJmsException(e);
            theMessageProducer.send(destination, aMessage);
        }
    }

    /**
     * Sends a message to the provided destination. The destination is looked up
     * via JNDI (default) or created with createTopic or createQueue based on the
     * destination type specified in the JmsClientConfiguration.
     *
     * @param aDestinationName the name of the destination
     * @param aMessage the message to send
     * @param aDeliveryMode the delivery mode to use
     * @param aPriority the priority for this message
     * @param aTimeToLive the message's lifetime (in milliseconds)
     * @throws NamingException if the destination type is JNDI and the destination is not found
     * @throws JMSException if an exception occurs while sending the message
     */
    public void send(String aDestinationName, Message aMessage, int aDeliveryMode, int aPriority, long aTimeToLive)
    throws NamingException, JMSException
    {
        Destination destination = getDestination(aDestinationName);

        try
        {
            theMessageProducer.send(destination, aMessage, aDeliveryMode, aPriority, aTimeToLive);
        }
        catch (JMSException e)
        {
            handleJmsException(e);
            theMessageProducer.send(destination, aMessage, aDeliveryMode, aPriority, aTimeToLive);
        }
    }

    /**
     * Creates a text message using the provided JMS headers and text.
     *
     * @param aJmsHeaderMap the map containing the JMS headers
     * @param aText the data for the JMS body
     * @return the message
     * @throws JMSException if an exception occurs while creating the message
     */
    public TextMessage createTextMessage(Map<String, Object> aJmsHeaderMap, String aText) throws JMSException
    {
        TextMessage message;

        try
        {
            message = doCreateTextMessage(aJmsHeaderMap, aText);
        }
        catch (JMSException e)
        {
            handleJmsException(e);
            message = doCreateTextMessage(aJmsHeaderMap, aText);
        }

        return message;
    }

    /**
     * Creates a text message using the provided JMS headers and text.
     *
     * @param aJmsHeaderMap the map containing the JMS headers
     * @param aByteArray the data for the JMS body
     * @return the message
     * @throws JMSException if an exception occurs while creating the message
     */
    public BytesMessage createBytesMessage(Map<String, Object> aJmsHeaderMap, byte[] aByteArray) throws JMSException
    {
        BytesMessage message;

        try
        {
            message = doCreateBytesMessage(aJmsHeaderMap, aByteArray);
        }
        catch (JMSException e)
        {
            handleJmsException(e);
            message = doCreateBytesMessage(aJmsHeaderMap, aByteArray);
        }

        return message;
    }

    /**
     * Creates a message using the provided JMS headers.
     *
     * @param aJmsHeaderMap the map containing the JMS headers
     * @return the message
     * @throws JMSException if an exception occurs while creating the message
     */
    public Message createNullBodyMessage(Map<String, Object> aJmsHeaderMap) throws JMSException
    {
        Message message;

        try
        {
            message = doCreateNullBodyMessage(aJmsHeaderMap);
        }
        catch (JMSException e)
        {
            handleJmsException(e);
            message = doCreateNullBodyMessage(aJmsHeaderMap);
        }

        return message;
    }

    /**
     * Copies an existing message to a new message created in this session.
     * Currently Bytes and Text messages are supported.
     *
     * @param aCopyFromMessage the message to copy
     * @return the new message
     * @throws JMSException if an exception occurs while copying the message or if the
     *                      message is not a bytes or test message.
     */
    public Message copyMessage(Message aCopyFromMessage) throws JMSException
    {
        Message copyToMessage;

        try
        {
            copyToMessage = doCopyMessage(aCopyFromMessage);
        }
        catch (JMSException e)
        {
            handleJmsException(e);
            copyToMessage = doCopyMessage(aCopyFromMessage);
        }

        return copyToMessage;
    }

    /**
     * Cleans up all of the JMS resources associated with this producer.
     */
    @Override
    public void close()
    {
        if (theMessageProducer != null)
        {
            try
            {
                theMessageProducer.close();
            }
            catch (JMSException e)
            {
                theLogger.warn(e.getMessage(), e);
            }
        }

        super.close();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void connect() throws NamingException, JMSException
    {
        super.connect();
        Destination destination = null;

        if (theConfiguration.getDestinationName() != null)
        {
            destination = getDestination(theConfiguration.getDestinationName());
        }

        theMessageProducer = theSession.createProducer(destination);

        theConnection.start();
    }

    /**
     * Creates a text message using the provided JMS headers and text.
     *
     * @param aJmsHeaderMap the map containing the JMS headers
     * @param aText the data for the JMS body
     * @return the message
     * @throws JMSException if an exception occurs while creating the message
     */
    private TextMessage doCreateTextMessage(Map<String, Object> aJmsHeaderMap, String aText) throws JMSException
    {
        TextMessage message = theSession.createTextMessage();
        addHeadersToMessage(message, aJmsHeaderMap);
        message.setText(aText);
        return message;
    }

    /**
     * Creates a text message using the provided JMS headers and text.
     *
     * @param aJmsHeaderMap the map containing the JMS headers
     * @param aByteArray the data for the JMS body
     * @return the message
     * @throws JMSException if an exception occurs while creating the message
     */
    private BytesMessage doCreateBytesMessage(Map<String, Object> aJmsHeaderMap, byte[] aByteArray) throws JMSException
    {
        BytesMessage message = theSession.createBytesMessage();
        addHeadersToMessage(message, aJmsHeaderMap);
        message.writeBytes(aByteArray);
        return message;
    }

    /**
     * Creates a message using the provided JMS headers.
     *
     * @param aJmsHeaderMap the map containing the JMS headers
     * @return the message
     * @throws JMSException if an exception occurs while creating the message
     */
    private Message doCreateNullBodyMessage(Map<String, Object> aJmsHeaderMap) throws JMSException
    {
        Message message = theSession.createMessage();
        addHeadersToMessage(message, aJmsHeaderMap);
        return message;
    }

    /**
     * Copies an existing message to a new message created in this session.
     * Currently Bytes and Text messages are supported.
     *
     * @param aCopyFromMessage the message to copy
     * @return the new message
     * @throws JMSException if an exception occurs while copying the message or if the
     *                      message is not a bytes or test message.
     */
    private Message doCopyMessage(Message aCopyFromMessage) throws JMSException
    {

        Message copyToMessage;

        // Copy body.
        if (aCopyFromMessage instanceof TextMessage)
        {
            TextMessage inboundMessage = (TextMessage) aCopyFromMessage;
            copyToMessage = theSession.createTextMessage(inboundMessage.getText());
        }
        else if (aCopyFromMessage instanceof BytesMessage)
        {
            BytesMessage inboundMessage = (BytesMessage) aCopyFromMessage;

            BytesMessage bytesMessage = theSession.createBytesMessage();
            if (inboundMessage.getBodyLength() <= Integer.MAX_VALUE)
            {
                byte[] buffer = new byte[(int) inboundMessage.getBodyLength()];
                inboundMessage.readBytes(buffer);
                bytesMessage.writeBytes(buffer);
            }
            else
            {
                theLogger.error("BytesMessage size is too large.");
            }
            copyToMessage = bytesMessage;
        }
        else
        {
            copyToMessage = theSession.createMessage();
        }

        // Copy headers.
        Enumeration<?> srcProperties = aCopyFromMessage.getPropertyNames();

        if (srcProperties != null)
        {
            while (srcProperties.hasMoreElements())
            {
                String propertyName = (String) srcProperties.nextElement();
                copyToMessage.setObjectProperty(propertyName, aCopyFromMessage.getObjectProperty(propertyName));
            }
        }

        return copyToMessage;
    }

    /**
     * Adds the headers in aJmsHeadersMap to the message.
     *
     * @param aMessage the message to add the headers to
     * @param aJmsHeaderMap the headers to add
     * @throws JMSException if an exception occurs while adding the headers
     */
    private void addHeadersToMessage(Message aMessage, Map<String, Object> aJmsHeaderMap) throws JMSException
    {
        if (aJmsHeaderMap != null)
        {
            for (Map.Entry<String, Object> entry : aJmsHeaderMap.entrySet())
            {
                aMessage.setObjectProperty(entry.getKey(), entry.getValue());
            }
        }
    }

    /**
     * Get the default delivery mode for this message producer.
     * This will be the value from the Connection Factory.
     * @return The the DeliveryMode value configured by the connection factory.
     * @throws JMSException if an exception occurs while adding the headers
     */
    public int getDefaultDeliveryMode() throws JMSException
    {
      return theMessageProducer.getDeliveryMode();
    }
}
