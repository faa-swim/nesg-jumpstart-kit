/*******************************************************************************
 * Copyright (c) 2021 - 2024 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jmsclient;

import java.util.Hashtable;
import java.util.Map;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
* Base class for creating  JMS clients.
*/
public abstract class JmsClient implements AutoCloseable, ExceptionListener
{
    protected final Logger theLogger = LoggerFactory.getLogger(getClass());

    protected JmsClientConfiguration theConfiguration;

    protected InitialContext theContext;
    protected Connection theConnection;
    protected Session theSession;

    protected ConnectionFactory theConnectionFactory;

    /**
     * Constructs a JMS client using the provided JMS Client Configuration.
     *
     * @param aConfiguration the configuration
     */
    public JmsClient(JmsClientConfiguration aConfiguration)
    {
        theConfiguration = aConfiguration;
        validateConfiguration();
    }

    /**
     * To be overridden and called by extending classes to initialize the JMS client.
     *
     * @throws NamingException if connection factory is not found
     * @throws JMSException if an exception is thrown creating the connection or session
     */
    public void connect() throws NamingException, JMSException
    {
        Hashtable<String, String> env = new Hashtable<>();
        if (theConfiguration.getContextFactory() == null)
        {
            throw new JMSException("No context factory set.");
        }
        env.put(Context.INITIAL_CONTEXT_FACTORY, theConfiguration.getContextFactory());
        env.put(Context.PROVIDER_URL, theConfiguration.getProviderUrl());

        if (theConfiguration.credentialsSet())
        {
            env.put(Context.SECURITY_PRINCIPAL, theConfiguration.getUsername());
            env.put(Context.SECURITY_CREDENTIALS, theConfiguration.getPassword());
        }

        if (theConfiguration.getAdditionalContextParams() != null)
        {
            env.putAll(theConfiguration.getAdditionalContextParams());
        }

        if (theLogger.isDebugEnabled())
        {
            for (Map.Entry entry : env.entrySet())
            {
                theLogger.debug("Initial context environment entry: key: {} value: {}", entry.getKey(),
                    entry.getValue());
            }
        }

        theContext = new InitialContext(env);

        theConnectionFactory = (ConnectionFactory) theContext.lookup(
            theConfiguration.getConnectionFactory());
        if (theConfiguration.credentialsSet())
        {
            theConnection = theConnectionFactory.createConnection(theConfiguration.getUsername(),
                theConfiguration.getPassword());
        }
        else
        {
            theConnection = theConnectionFactory.createConnection();
        }

        theConnection.setExceptionListener(this);

        String ackType = theConfiguration.getAckType();
        boolean isTransacted = theConfiguration.getIsTransacted();

        if (ackType.equals("CLIENT_ACKNOWLEDGE"))
        {
            theSession = theConnection.createSession(isTransacted, Session.CLIENT_ACKNOWLEDGE);
        }
        else if (ackType.equals("AUTO_ACKNOWLEDGE"))
        {
            theSession = theConnection.createSession(isTransacted, Session.AUTO_ACKNOWLEDGE);
        }
        else if (ackType.equals("DUPS_OK_ACKNOWLEDGE"))
        {
            theSession = theConnection.createSession(isTransacted, Session.DUPS_OK_ACKNOWLEDGE);
        }
        else
        {
            throw new IllegalArgumentException("Unknown Acknowledgement Type" + " " + ackType);
        }
    }

    /**
     * Commits the current transaction.
     */
    public void commit()
    {
        try
        {
            theSession.commit();
        }
        catch (JMSException e)
        {
            theLogger.warn(e.getMessage(), e);
        }
    }

    /**
     * Rolls back the current transaction.
     */
    public void rollback()
    {
        try
        {
            theSession.rollback();
        }
        catch (JMSException e)
        {
            theLogger.warn(e.getMessage(), e);
        }
    }

    /**
     * Recovers the current session.
     */
    public void recover()
    {
        try
        {
            theSession.recover();
        }
        catch (JMSException e)
        {
            theLogger.warn(e.getMessage(), e);
        }
    }


    /**
     * Closes all of the JMS resources. Any overriding classes should call this after any other additional cleanup to
     * insure that all resources are cleaned up.
     */
    @Override
    public void close()
    {
        if (theSession != null)
        {
            try
            {
                theSession.close();
            }
            catch (JMSException e)
            {
                theLogger.warn(e.getMessage(), e);
            }
        }

        if (theConnection != null)
        {
            try
            {
                theConnection.close();
            }
            catch (JMSException e)
            {
                theLogger.warn(e.getMessage(), e);
            }
        }

        if (theContext != null)
        {
            try
            {
                theContext.close();
            }
            catch (NamingException e)
            {
                theLogger.warn(e.getMessage(), e);
            }
        }
    }

    /**
     * Attempts to close the current resources. Then attempts to reconnect and create a new session.
     * This method will block trying to reconnect until a connection is established or until the
     * JmsClientConfiguration.getMaxConnectionRetries is reached. The
     * JmsClientConfiguration.getIntervalBetweenConnectionRetries specifies the time between reconnect attempts.
     * Setting the JmsClientConfiguration.getMaxConnectionRetries to -1 will result in retrying until connected.
     * Setting the JmsClientConfiguration.getMaxConnectionRetries to 0 will result in not retrying and a
     * JMSException thrown that Exhausted all retry attempts.
     *
     * @throws JMSException if the max connection retries is reached
     */
    public void reconnect() throws JMSException
    {
        int connectionAttempt = 0;
        boolean connected =  false;
        while (!connected && (theConfiguration.getMaxConnectionRetries() < 0 ||
            connectionAttempt < theConfiguration.getMaxConnectionRetries()))
        {
            close();
            try
            {
                if (theConfiguration.getIsTransacted())
                {
                    theSession.rollback();
                }
                connect();
                connected = true;
            }
            catch (Exception e)
            {
                if (theLogger.isWarnEnabled())
                {
                    theLogger.warn(e.getMessage(), e);
                }

                try
                {
                    Thread.sleep(theConfiguration.getIntervalBetweenConnectionRetries());
                }
                catch (InterruptedException e1)
                {
                    Thread.currentThread().interrupt();
                    break;
                }
            }

            connectionAttempt++;
        }

        if (!connected)
        {
            throw new JMSException("Exhausted all retry attempts");
        }
    }

    /**
     * Uses the JmsClientConfiguration.getExceptionHandler() to handle any exceptions.
     *
     * {@inheritDoc}
     */
    @Override
    public void onException(JMSException anException)
    {
        handleException(anException);
    }

    /**
     * Gets a destination object for the given name based on the the destination
     * type configured in the JmsClientConfiguration.
     *
     * @param aDestinationName the name of the destination
     * @return the resulting destination
     * @throws NamingException if the destination type is JNDI and the destination is not found
     * @throws JMSException if the destination type is queue or topic and the destination can not be created
     */
    public Destination getDestination(String aDestinationName) throws NamingException, JMSException
    {
        Destination destination;

        try
        {
            destination = doGetDestination(aDestinationName);
        }
        catch (NamingException e)
        {
            handleNamingException(e);
            destination = doGetDestination(aDestinationName);
        }
        catch (JMSException e)
        {
            handleJmsException(e);
            destination = doGetDestination(aDestinationName);
        }

        return destination;
    }

    /**
     * Convenience method to handle JMS exceptions.
     *
     * @param anException the exception to handle
     * @throws JMSException the exception if it could not be handled
     */
    protected void handleJmsException(JMSException anException) throws JMSException
    {
        if (!handleException(anException))
        {
            throw anException;
        }
    }

    /**
     * Validates the {@link JmsClientConfiguration} is valid.
     *
     * @throws IllegalArgumentException if the configuration is not valid
     */
    protected void validateConfiguration() throws IllegalArgumentException
    {
        if (theConfiguration.getContextFactory() == null)
        {
            throw new IllegalArgumentException("Initial Context Factory not set.");
        }

        if (theConfiguration.getProviderUrl() == null)
        {
            throw new IllegalArgumentException("Provider URL not set.");
        }

        if (JmsClientConfiguration.AUTH_TYPE_BASIC.equals(theConfiguration.getAuthType()) &&
            !theConfiguration.credentialsSet())
        {
            throw new IllegalArgumentException("Username and password must be set when using basic authentication");
        }

        if (theConfiguration.getConnectionFactory() == null)
        {
            throw new IllegalArgumentException("Connection Factory not set");
        }
    }

    /**
     * Convenience method to handle naming exceptions.
     *
     * @param anException the exception to handle
     * @throws NamingException the exception if it could not be handled
     */
    protected void handleNamingException(NamingException anException) throws NamingException
    {
        if (!handleException(anException))
        {
            throw anException;
        }
    }

    /**
     * Attempts to reconnect to the JMS destination.
     *
     * @param aThrowable the exception to handle.
     * @return true if the reconnect was successful
     */
    private boolean handleException(Throwable aThrowable)
    {
        boolean handled = false;
        theLogger.info(aThrowable.getMessage(), aThrowable);

        try
        {
            if (theConfiguration.getIsTransacted())
            {
                theSession.rollback();
            }

            reconnect();
            handled = true;
        }
        catch (JMSException e)
        {
            if (theLogger.isWarnEnabled())
            {
                theLogger.warn("Unable to reconnect: {}", e.getMessage(), e);
            }
        }

        return handled;
    }

    /**
     * Gets a destination object for the given name based on the the destination
     * type configured in the JmsClientConfiguration.
     *
     * @param aDestinationName the name of the destination
     * @return the resulting destination
     * @throws NamingException if the destination type is JNDI and the destination is not found
     * @throws JMSException if the destination type is queue or topic and the destination can not be created
     */
    private Destination doGetDestination(String aDestinationName) throws NamingException, JMSException
    {
        Destination destination;

        switch (theConfiguration.getDestinationType())
        {
            case JmsClientConfiguration.DESTINATION_TYPE_QUEUE:
            destination = theSession.createQueue(aDestinationName);
            break;

            case JmsClientConfiguration.DESTINATION_TYPE_TOPIC:
            destination = theSession.createTopic(aDestinationName);
            break;

            case JmsClientConfiguration.DESTINATION_TYPE_JNDI:
            default:
            destination = (Destination) theContext.lookup(aDestinationName);
            break;
        }

        return destination;
    }

    public ConnectionFactory getConnectionFactory()
    {
      return theConnectionFactory;
    }
}
