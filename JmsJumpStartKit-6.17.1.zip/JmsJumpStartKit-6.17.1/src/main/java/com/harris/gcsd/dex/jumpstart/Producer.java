/*******************************************************************************
 * Copyright (c) 2021 - 2024 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jumpstart;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.TimeUnit;

import com.harris.gcsd.dex.jmsclient.JmsClientConfiguration;
import com.harris.gcsd.dex.jmsclient.JmsProducer;
import com.harris.gcsd.dex.jumpstart.input.ConsoleInput;
import com.harris.gcsd.dex.jumpstart.input.FileInput;
import com.harris.gcsd.dex.jumpstart.input.Input;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.text.NumberFormat;
/**
 * JMS producer implementation.
 */
public class Producer implements AutoCloseable, Runnable
{
  private static final Options OPTIONS = getOptions();
  private static final int MILLISECONDS_IN_SECOND = 1000;
  private static final int TIMES_PER_SECOND = 5;
  private static final String PRODUCER_TIMESTAMP = "JSKTimestamp";
  private static final String DEAD_MESSAGE_QUEUE_HEADER = "JMS_Solace_DeadMsgQueueEligible";

  private static final int DEFAULT_BYTE_STREAM_SIZE = 5000;
  private static final String DEFAULT_MESSAGE = "Test Message";
  private static final String DEFAULT_PROPERTIES_FILE = "../conf/producer.properties";
  private static final int DEFAULT_PRIORITY = 4;
  private static final int DEFAULT_DELIVERY_MODE = 1;
  private static final int DEFAULT_MESSAGE_NUMBER = 10;
  private static final int SOLACE_MAX_TRANSACTION = 255;
  private static final double DEFAULT_MESSAGE_RATE = 12000.0;

  private static final long DEFAULT_LATCH_TIMEOUT_TIME = 5L;
  private static final double LOW_RATE_TIMEOUT_THRESHOLD = 0.5;

  private static final long LOW_RATE_PRINTING_THRESHOLD = 2000;
  private static final long MILIS_BETWEEN_DOTS = 500;

  private static int theProducerNumber = 1;
  private static AtomicLong totalMessages = new AtomicLong();
  private static AtomicLong theMessageID = new AtomicLong();

  private JmsClientConfiguration theJmsConfiguration;
  private JmsProducer theProducer;
  private Input theInput;
  //The total number of messages to send
  private int theMessageNumber;
  //desired message rate in messages per second
  private double theMessageRate;
  private double theMaxMessageRate;

  private boolean theMeasureLatency = false;
  private long theTTL = 0L;
  private int thePriority = DEFAULT_PRIORITY;
  // The Delivery mode set by the command line option -dm
  private int theCommandLineDeliveryMode = 0;
  // The Delivery mode set by the connection factory
  private int theConnectionFactoryDeliveryMode = 0;
  // The Delivery mode to send messages with 
  private int theDeliveryMode = 0;
  // Was the delivery mode overridden using the command line option "-dm"?
  private boolean theDeliveryModeOverride = false;
  private Boolean theDeadMessageQueueHeader = null;

  private int theProducerID;
  // the rate that the producer was actually able to send the messages at
  // in messages per second.
  private double theCalculatedRate;
  private StringBuilder theOutputString;

  private final CountDownLatch theStartLatch;
  private final CountDownLatch theDoneLatch;
  private NumberFormat theNumberFormat;

  // Counters for transactions
  private long theTransactionCounter = 1;
  private long theTransactionLimit = 1;

  // Interrupt status for producers to check
  private static boolean theInterruptStatus = false;

  // Timeout time for shutdown latch
  private static Long theLatchTimeoutTime = DEFAULT_LATCH_TIMEOUT_TIME;

  /**
   * Constructor that creates a producer from the command line args
   *
   * @param anArgs the args
   * @param aID the producer ID
   * @param aStartLatch the starting latch
   * @param aDoneLatch the latch to call when done
   */
  public Producer(String[] anArgs, int aID, CountDownLatch aStartLatch, CountDownLatch aDoneLatch)
  {
    parseArgs(anArgs);
    theProducerID = aID;
    theStartLatch = aStartLatch;
    theDoneLatch = aDoneLatch;

    theProducer = new JmsProducer(theJmsConfiguration);
    theNumberFormat = NumberFormat.getInstance();
    theNumberFormat.setMaximumFractionDigits(2);
    theNumberFormat.setMinimumFractionDigits(2);

    if (theJmsConfiguration.getIsTransacted())
    {
      if (theJmsConfiguration.getTransactionLimit() > 0)
      {
        theTransactionLimit = theJmsConfiguration.getTransactionLimit();
      }
    }
  }

  @Override
  public void run()
  {
    try
    {
      theStartLatch.await();
      theProducer.connect();
    }
    catch (Exception e)
    {
      theDoneLatch.countDown();
      if (e.getMessage() != null)
      {
        throw new RuntimeException("Exception while connecting: " + e.getMessage(), e);
      }
      else
      {
        throw new RuntimeException("RootException while connecting: " + e.getCause().getMessage(), e);
      }
    }
    try
    {
      if (!theJmsConfiguration.getDestinationType().equals("topic"))
      {
        System.out.println("Producer producing to: " + theJmsConfiguration.getDestinationName());
      }
      else if (theJmsConfiguration.getDestinationName() == null)
      {
        System.out.println("Producer producing to topics via format string");
      }
      else
      {
        System.out.println("Topic producer started to topic: " + theJmsConfiguration.getDestinationName());
      }
    
      theConnectionFactoryDeliveryMode = theProducer.getDefaultDeliveryMode();
      if (theDeliveryModeOverride)
      {
        theDeliveryMode = theCommandLineDeliveryMode;
      }
      else
      {
        theDeliveryMode = theConnectionFactoryDeliveryMode;
      }

      //Creates the batched message count list
      int[] messageCountList = new int[TIMES_PER_SECOND];
      for (int i = 0; i < TIMES_PER_SECOND; i++)
      {
        if ((theMessageRate - (theMessageRate % 1)) % TIMES_PER_SECOND > i)
        {
          messageCountList[i] += 1;
        }

        messageCountList[i] += (theMessageRate - (theMessageRate % TIMES_PER_SECOND)) / TIMES_PER_SECOND;
      }

      int totalCount = 0;
      int count = 0;
      double leftoverMessages = theProducerID * (theMessageRate % 1);

      long start = System.currentTimeMillis();
      int cursorPosition = 0;

      double targetElapsedTime = 0;

      String formatString = theJmsConfiguration.getFormatString();

      while (totalCount < theMessageNumber)
      {
        if (theJmsConfiguration.getIsTransacted())
        {
          theProducer.commit();
        }

        //Loops through one batch of messages, calculated based off of the messageCountList
        int messagesInBatch = messageCountList[cursorPosition] + (int) (leftoverMessages -
            (leftoverMessages % 1));
        for (int i = 0; i < messagesInBatch; i++)
        {
          GenericMessage message = theInput.next();
          message.addProperty("JSKMessageID", Long.toString(theMessageID.getAndIncrement()));
          if (theMeasureLatency)
          {
            long timestamp = System.currentTimeMillis();
            message.addProperty(PRODUCER_TIMESTAMP, timestamp);
          }

          if (theDeadMessageQueueHeader != null)
          {
              message.addProperty(DEAD_MESSAGE_QUEUE_HEADER, theDeadMessageQueueHeader);
          }

          Object content = message.getContent();
          //Sends the message
          if (theJmsConfiguration.getDestinationType().compareTo("topic") == 0 && formatString != null)
          {
            String topicName = SolaceUtil.buildTopicName(formatString, message.getProperties());


            if (content instanceof String)
            {
              theProducer.send(topicName, theProducer.createTextMessage(message.getProperties(),
                    message.getContent(String.class)), theDeliveryMode, thePriority, theTTL);
            }
            else
            {

              theProducer.send(topicName, theProducer.createBytesMessage(message.getProperties(),
                    toByteArray(content)), theDeliveryMode, thePriority, theTTL);

            }

          }
          else
          {

            if (content instanceof String)
            {

              theProducer.send(theProducer.createTextMessage(message.getProperties(),
                    (String) content), theDeliveryMode, thePriority, theTTL);
            }
            else
            {

              theProducer.send(theProducer.createBytesMessage(message.getProperties(),
                    toByteArray(content)), theDeliveryMode, thePriority, theTTL);

            }
          }

          if (theJmsConfiguration.getIsTransacted())
          {
            // Check if we're ready to commit the transaction.
            if (theTransactionCounter >= theTransactionLimit)
            {
              theProducer.commit();
              theTransactionCounter = 1;
            }
            else
            {
              // If we aren't ready to commit, increment the counter.
              theTransactionCounter++;
            }
          }

          count++;
          totalCount++;
          if (totalCount >= theMessageNumber)
          {
            // Commit any leftover messages that were not caught by the limit
            if (theJmsConfiguration.getIsTransacted())
            {
              theProducer.commit();
            }
            break;
          }
        }

        //Reduces the leftover message count if an extra message was sent (i.e. it is above one)
        if (leftoverMessages >= 1)
        {
          leftoverMessages = leftoverMessages % 1;
        }

        //Calculates the time to sleep based off of how long the messages took to send
        double sleepTime = theMessageRate > 0 ? count * MILLISECONDS_IN_SECOND
         / theMessageRate : MILLISECONDS_IN_SECOND;
        double diffElapsedTime = System.currentTimeMillis() - start
         - targetElapsedTime;
        long threadSleepTime = (long) (sleepTime - diffElapsedTime);

        if (threadSleepTime > LOW_RATE_PRINTING_THRESHOLD && theProducerID == 1)
        {

          System.out.print("Waiting for next batch");
          long remainderSleepMilis = threadSleepTime % MILIS_BETWEEN_DOTS;
          long sleepPrintCycles = (threadSleepTime - remainderSleepMilis) / MILIS_BETWEEN_DOTS;

          for (int i = 0; i < sleepPrintCycles; i++)
          {
            System.out.print(".");
            Thread.sleep(MILIS_BETWEEN_DOTS);
          }
          System.out.println(".");
          Thread.sleep(remainderSleepMilis);

        }
         else if (threadSleepTime >= 0) 
        {
          Thread.sleep(threadSleepTime);
        }

        //Increases the message count and/or prints the rate and message count
        if (theProducerID == 1 && (count > 0 || theMessageRate == 0))
        {
          double currentDuration = (double) (System.currentTimeMillis() - start)
           / MILLISECONDS_IN_SECOND;
          long currentMessageCount = totalMessages.addAndGet(count);
          theCalculatedRate = (double) (totalCount * theProducerNumber)
           / currentDuration;
          System.out.println("Message rate: " + theNumberFormat.format(
            theCalculatedRate) + "    Messages sent: " + currentMessageCount);
        }
        else
        {
          totalMessages.addAndGet(count);
        }

        targetElapsedTime += sleepTime;

        //Resets the batched message count and increments to the next batch
        count = 0;
        cursorPosition++;

        if (cursorPosition >= messageCountList.length)
        {
          cursorPosition = 0;
          leftoverMessages += theMessageRate % 1;
        }

        // checks if program has been interrupted and breaks loop
        if (theInterruptStatus)
        {
          break;
        }
      }

      //Calculates the final stats of the producer
      long stop = System.currentTimeMillis();
      double period = (double) (stop - start) / MILLISECONDS_IN_SECOND;
      theCalculatedRate = 0;
      if (period > 0)
      {
        theCalculatedRate = (double) totalCount / period;
      }
      theOutputString = new StringBuilder("\nProducer " + theProducerID + " was producing to: " +
          (theJmsConfiguration.getDestinationName() != null ? 
          theJmsConfiguration.getDestinationName() : "topic") + "\n" +
          "Total messages:  " + totalCount + "\n" +
          "Time in seconds: " + period + "\n" +
          "Configured Rate: " + theNumberFormat.format(theMessageRate) + "\n" +
          "Actual Rate:     " + theNumberFormat.format(theCalculatedRate));
    }
    catch (Exception e)
    {
      theProducer.rollback();
      theDoneLatch.countDown();
      throw new RuntimeException("Exception while Producing: " + e.getMessage(), e);
    }
    theDoneLatch.countDown();
  }

  /**
   * Gets the configured message rate
   *
   * @return the configured rate
   */
  public double getConfiguredRate()
  {
    return theMessageRate;
  }

  /**
   * Gets the calculated message rate.
   *
   * @return the calculated rate
   */
  public double getCalculatedRate()
  {
    return theCalculatedRate;
  }

  /**
   * Gets the output string.
   *
   * @return the output string
   */
  public String getOutputString()
  {
    if (theOutputString == null)
    {
      return "";
    }
    else
    {
      return theOutputString.toString();
    }
  }

  @Override
  public void close()
  {
    if (theProducer != null)
    {

      if (theJmsConfiguration.getIsTransacted())
      {
        theProducer.rollback();
        System.out.println("The transaction was rolled back.");
      }
      theProducer.close();
    }
  }

  /**
   * Parses the args.
   *
   * @param anArgs the command line args
   */
  private void parseArgs(String[] anArgs)
  {
    String currentParse = "";

    try
    {
      CommandLineParser parser = new DefaultParser();
      CommandLine line = parser.parse(OPTIONS, anArgs);

      if (line.hasOption('h'))
      {
        currentParse = "-h";
        printUsage();
        System.exit(0);
      }

      String propertiesFile = DEFAULT_PROPERTIES_FILE;

      if (line.hasOption("pf"))
      {
        currentParse = "-pf";
        propertiesFile = line.getOptionValue("pf").trim();
      }

      theJmsConfiguration = new JmsClientConfiguration(propertiesFile);

      if (line.hasOption('d'))
      {
        currentParse = "-d";
        File directory = new File(line.getOptionValue('d').trim());
        theInput = new FileInput(directory);
      }
      else if (line.hasOption("m"))
      {
        currentParse = "-m";
        theInput = new ConsoleInput(new GenericMessage(line.getOptionValue("m").trim()));
      }
      else
      {
        currentParse = "DEFAULT_MESSAGE";
        theInput = new ConsoleInput(new GenericMessage(DEFAULT_MESSAGE));
      }

      if (line.hasOption("mn"))
      {
        currentParse = "-mn";
        theMessageNumber = Integer.parseInt(line.getOptionValue("mn").trim()) / theProducerNumber;
      }


      if (line.hasOption("mmr"))
      {
        currentParse = "-mmr";
        theMaxMessageRate = Double.parseDouble(line.getOptionValue("mmr").trim());
        if (theMaxMessageRate < 1)
        {
          throw new IllegalArgumentException("Max messaging rate cannot be less than 1.");
        }
      }
      else
      {
        theMaxMessageRate = DEFAULT_MESSAGE_RATE;
      }

      if (line.hasOption("mr"))
      {
        currentParse = "-mr";
        theMessageRate = Double.parseDouble(line.getOptionValue("mr").trim());
        if (theMaxMessageRate < theMessageRate)
        {
          theMessageRate = theMaxMessageRate / theProducerNumber;
        }
        else
        {
          theMessageRate = theMessageRate / theProducerNumber;
        }
      }
      else
      {
        theMessageRate = 1 / theProducerNumber;
      }
      if (theMessageRate < LOW_RATE_TIMEOUT_THRESHOLD)
      {
        theLatchTimeoutTime = (long) (1 / theMessageRate);
      }

      if (line.hasOption("l"))
      {
        theMeasureLatency = true;
      }

      if (line.hasOption("ttl"))
      {
        theTTL = Long.parseLong(line.getOptionValue("ttl").trim());
      }

      if (line.hasOption("pr"))
      {
        thePriority = Integer.parseInt(line.getOptionValue("pr").trim());
      }

      if (line.hasOption("dm"))
      {
        theDeliveryModeOverride = true;
        theCommandLineDeliveryMode = Integer.parseInt(line.getOptionValue("dm").trim());
        theDeliveryMode = theCommandLineDeliveryMode;
      }

      if (line.hasOption("dmq"))
      {
        theDeadMessageQueueHeader = Boolean.valueOf(line.getOptionValue("dmq").trim());
      }
    }

    // Catches the directory file exception
    catch (NullPointerException e)
    {
      throw new RuntimeException("Parsing failed on " + currentParse + ". Reason: Directory not found.");
    }
    // Catches the rest of the exceptions
    catch (Exception e)
    {
      throw new RuntimeException("Parsing failed on " + currentParse + ". Reason: " + e.getMessage());
    }

    validateArgs();
  }

  /**
   * Validates the command line args.
   */
  private void validateArgs()
  {
    if (theInput == null)
    {
      throw new RuntimeException("Either a message or input directory must be set");
    }

    if (theMessageNumber <= 0)
    {
      theMessageNumber = DEFAULT_MESSAGE_NUMBER;
    }
  }

  /**
   * Parses the args for the producer group.
   *
   * @param anArgs the command line args
   */
  protected static void parseCommandArgs(String[] anArgs)
  {
    try
    {
      CommandLineParser parser = new DefaultParser();
      CommandLine line = parser.parse(OPTIONS, anArgs);

      if (line.hasOption("pn"))
      {
        theProducerNumber = Integer.parseInt(line.getOptionValue("pn").trim());
      }

    }
    catch (Exception e)
    {
      throw new RuntimeException("Parsing failed. Reason: " + e.getMessage());
    }
  }

  /**
   * Creates the Options object.
   *
   * @return the options
   */
  private static Options getOptions()
  {
    Options options = new Options();
    options.addOption(Option.builder("d").longOpt("directory").hasArg().
        desc("Directory load messages from").build());
    options.addOption(Option.builder("dm").longOpt("delivery_mode").hasArg().
        desc("Overrides the default delivery mode").build());
    options.addOption(Option.builder("h").longOpt("help").desc("Print this message").build());
    options.addOption(Option.builder("l").longOpt("latency").
        desc("Add a timestamp to calculate latency. Latency flag must also be set on consumer.").build());
    options.addOption(Option.builder("m").longOpt("message").hasArg().desc("Message to produce").build());
    options.addOption(Option.builder("mn").longOpt("message_number").hasArg().
        desc("Total number of messages to produce").build());
    options.addOption(Option.builder("mr").longOpt("message_rate").hasArg().
        desc("Rate at which to produce messages in messages per second.").build());
    options.addOption(Option.builder("mmr").longOpt("max_message_rate").hasArg().
        desc("Overrides the default max message rate. Going above the default may impact the broker").build());
    options.addOption(Option.builder("pf").longOpt("property_file").hasArg().
        desc("Overrides the default properties file location").build());
    options.addOption(Option.builder("pn").longOpt("producer_number").hasArg().
        desc("Overrides the default number of producers").build());
    options.addOption(Option.builder("pr").longOpt("priority").hasArg().
        desc("Overrides the default priority").build());
    options.addOption(Option.builder("ttl").longOpt("time_to_live").hasArg().
        desc("Overrides the default time to live in milliseconds").build());
    options.addOption(Option.builder("dmq").longOpt("dead_message_queue").hasArg().
        desc("Sets the Solace dead message queue header [true|false]").build());
    return options;
  }

  /**
   * Prints the usage statement.
   */
  private static void printUsage()
  {
    HelpFormatter formatter = new HelpFormatter();
    formatter.printHelp("producer", OPTIONS, true);
  }

  /**
   * Main entry point for the Producer.
   *
   * @param anArgs use -h to show usage
   */
  public static void main(String[] anArgs)
  {
    ArrayList<Producer> producerList = new ArrayList<Producer>();
    parseCommandArgs(anArgs);
    final CountDownLatch theStartLatch = new CountDownLatch(1);
    final CountDownLatch theDoneLatch = new CountDownLatch(theProducerNumber);
    ExecutorService theExecutor = Executors.newFixedThreadPool(theProducerNumber);

    for (int i = 0; i < theProducerNumber; i++)
    {
      try
      {
        Producer producer = new Producer(anArgs, i + 1, theStartLatch, theDoneLatch);
        theExecutor.execute(producer);
        producerList.add(producer);
      }
      catch (Exception e)
      {
        System.err.println("");
        e.printStackTrace();
        if (theExecutor != null)
        {
          theExecutor.shutdown();
        }
        System.exit(1);
      }
    }

    // shutdown hook to handle normal exits *and* interrupts
    try
    {
      Runtime.getRuntime().addShutdownHook(new Thread()
          {
            public void run()
            {

              System.out.println("\nProcess Ending...");

              // check if the producers are finished and sets interrupt status
              if (theDoneLatch.getCount() > 0)
              {
                theInterruptStatus = true;
              }

              // waits until producers end cleanly, update stats, etc
              try
              {
                theDoneLatch.await(theLatchTimeoutTime, TimeUnit.SECONDS);
              }
              catch (InterruptedException e)
              {
                Thread.currentThread().interrupt();
              }

              // calculates the total messages and rate across all producers
              double configuredRate = 0.0;
              double totalRate = 0.0;
              NumberFormat theNumberFormat = NumberFormat.getInstance();
              theNumberFormat.setMaximumFractionDigits(2);

              for (int i = 0; i < theProducerNumber; i++)
              {
                if (i == 0)
                {   
                  // gets configured rates from ONLY first thread and multiplies
                  configuredRate = producerList.get(i).getConfiguredRate() * (double) theProducerNumber;
                }

                // adds together real rates from each thread
                totalRate += producerList.get(i).getCalculatedRate();

                // prints stats per producer
                String producerOutputString = producerList.get(i).getOutputString();
                if (producerOutputString != "")
                {
                  System.out.println(producerOutputString);
                }
              }

              // prints overall stats if more than one producer
              if (theProducerNumber > 1)
              {
                System.out.println("\nOverall Stats:" +
                    "\nTotal messages:  " + totalMessages.get() +
                    "\nConfigured Rate: " + theNumberFormat.format(configuredRate) +
                    "\nCalculated Rate: " + theNumberFormat.format(totalRate));
              }
            }
          });
    }
    catch (Exception e)
    {
      System.err.println("");
      e.printStackTrace();
      System.exit(1);
    }

    theStartLatch.countDown();
    try
    {
      theDoneLatch.await();
    }
    catch (Exception e)
    {
      System.err.println("");
      e.printStackTrace();
      if (theExecutor != null)
      {
        theExecutor.shutdown();
      }
      System.exit(1);
    }

    if (theExecutor != null)
    {
      theExecutor.shutdown();
    }
    System.exit(0);
  }


  /**
   * Convert an object to a byte array for Bytes Messages.
   * @param aObj The object to convert to a byteArray
   * @return the byteArray representing the object.
   */
  private byte[] toByteArray(Object aObj)
  {
    ByteArrayOutputStream byteStream = new ByteArrayOutputStream(DEFAULT_BYTE_STREAM_SIZE);
    try
    {
      ObjectOutputStream os = new ObjectOutputStream(new BufferedOutputStream(byteStream));
      os.flush();
      os.writeObject(aObj);
      os.flush();
    }
    catch (IOException e) 
    {
      System.out.println("Exception creating Bytes Message:" + e.toString());
      e.printStackTrace();
    }
    return byteStream.toByteArray();
  }

}
