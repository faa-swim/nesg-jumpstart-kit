/*******************************************************************************
 * Copyright (c) 2021 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jumpstart;

import java.util.Map;

/**
 * Utility methods used for solace
 */
public class SolaceUtil
{

    private static final String SOLACE_DELIMITER = "/";
    private static final String REGEX_DELIMITER = ":";

    /**
     * Recursively generates a solace topic name from the attributes based on the format string. All properties with
     * the exception of DEX_SOURCE_TYPE are assumed to be optional. If a property is missing or has a null or empty
     * value it is handled as follows; If it is at the end of the topic name it is not included. If it is in the
     * middle of the name the name of the properties is used.
     *
     * @param aFormatString the format string. Must be in the format
     *                      ${DEX_SOURCE_TYPE}:${PropertyName1}:${PropertyNameN}
     * @param aProperties the map of property names to property values
     * @return the solace formatted topic name
     */
    public static String buildTopicName(String aFormatString, Map<String, Object> aProperties)
    {
        StringBuilder result = new StringBuilder();
        buildTopicName(result, aFormatString, aProperties);
        return result.toString();
    }

    /**
     * Recursively generates a solace topic name from the attributes based on the format string. All properties with
     * the exception of DEX_SOURCE_TYPE are assumed to be optional. If a property is missing or has a null or empty
     * value it is handled as follows; If it is at the end of the topic name it is not included. If it is in the
     * middle of the name the name of the properties is used.
     *
     * @param aResult a builder to hold the resulting solace formatted topic name
     * @param aFormatString the format string. Must be in the format
     *                      ${DEX_SOURCE_TYPE}:${PropertyName1}:${PropertyNameN}
     * @param aProperties the map of property names to property values
     */
    private static void buildTopicName(StringBuilder aResult, String aFormatString, Map<String, Object> aProperties)
    {
        String propertyName;
        String remainingFormatString;

        int index = aFormatString.indexOf(REGEX_DELIMITER);
        if (index >= 0)
        {
            //Get the property name minus the ${ and }.
            propertyName = aFormatString.substring(2, index - 1);
            remainingFormatString = aFormatString.substring(index + 1, aFormatString.length());

            buildTopicName(aResult, remainingFormatString, aProperties);

            Object propertyValue = aProperties.get(propertyName);
            if (propertyValue != null && !"".equals(propertyValue.toString()))
            {
                if (aResult.length() > 0)
                {
                    aResult.insert(0, SOLACE_DELIMITER);
                }

                aResult.insert(0, removeReservedCharaters(propertyValue.toString()));
            }
            else
            {
                if (aResult.length() > 0)
                {
                    aResult.insert(0, SOLACE_DELIMITER);
                    aResult.insert(0, removeReservedCharaters(propertyName));
                }
            }
        }
        else
        {
            //Get the property name minus the ${ and }.
            propertyName = aFormatString.substring(2, aFormatString.length() - 1);

            Object propertyValue = aProperties.get(propertyName);
            if (propertyValue != null && !"".equals(propertyValue.toString()))
            {
                aResult.append(removeReservedCharaters(propertyValue.toString()));
            }
        }
    }

    /**
     * Removes any characters not allowed to be in Solace topic name.
     *
     * @param aString the string to remove characters from
     * @return the updated string with out the reserved characters
     */
    private static String removeReservedCharaters(String aString)
    {
        return aString.replaceAll("[\\<>*]", "");
    }
}