/*******************************************************************************
 * Copyright (c) 2021 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jumpstart;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

/**
 * Utility to read and write content to files.
 */
public class FileUtil
{
    /**
     * Reads the byte contents of the file into a byte array.
     *
     * @param aFile the file to be read
     * @return the bytes
     * @throws IOException if the file can not be read
     */
    public static byte[] readBytes(File aFile) throws IOException
    {
        byte[] byteArray = new byte[(int) aFile.length()];
        try (InputStream inputStream = new FileInputStream(aFile))
        {
            inputStream.read(byteArray);
        }

        return byteArray;
    }

    /**
     * Reads the text contents of the file into a String.
     *
     * @param aFile the file to be read
     * @return the text
     * @throws IOException if the file can not be read
     */
    public static String readText(File aFile) throws IOException
    {
        StringBuilder stringBuilder = new StringBuilder();

        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(aFile)))
        {
            String line = bufferedReader.readLine();
            while (line != null)
            {
                stringBuilder.append(line);
                stringBuilder.append(System.getProperty("line.separator"));
                line = bufferedReader.readLine();
            }
        }

        return stringBuilder.toString();
    }

    /**
     * Detects if message content is well-formed XML.
     *
     *@param aMessage the message to be read
     *@return true if message content is well-formed xml
     *@throws SAXException if xml isn't well-formed
     *@throws ParserConfigurationException if xml cannot be parsed
     *@throws IOException if the message cannot be read
     */
    public static boolean isXml(String aMessage) throws SAXException, ParserConfigurationException, IOException
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        SimpleErrorHandler handler = new SimpleErrorHandler();
        factory.setValidating(false);
        factory.setNamespaceAware(true);

        try
        {
            StringReader sReader = new StringReader(aMessage);
            DocumentBuilder dBuilder = factory.newDocumentBuilder();
            dBuilder.setErrorHandler(handler);
            Document doc = dBuilder.parse(new InputSource(new StringReader(aMessage)));
        }
        catch (SAXException se)
        {
            return false;
        }
        catch (ParserConfigurationException pe)
        {
            return false;
        }
        catch (IOException e)
        {
            return false;
        }

        return !handler.recievedError();
    }

    /**
     * Writes a bytes to a file.
     *
     * @param aFile the file to write to
     * @param aBytes the bytes
     * @throws IOException if the file can not be written
     */
    public static void writeBytes(File aFile, byte[] aBytes) throws IOException
    {
        try (OutputStream outputStream = new FileOutputStream(aFile))
        {
            outputStream.write(aBytes);
        }
    }

    /**
     * Writes text to a file.
     *
     * @param aFile the file to write to
     * @param aText the text
     * @throws IOException if the file can not be written
     */
    public static void writeText(File aFile, String aText) throws IOException
    {
        writeBytes(aFile, aText.getBytes());
    }
}
