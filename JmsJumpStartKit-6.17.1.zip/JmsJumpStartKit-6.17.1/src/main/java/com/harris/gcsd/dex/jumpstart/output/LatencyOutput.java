/*******************************************************************************
 * Copyright (c) 2021 L3Harris Technologies
 *
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jumpstart.output;

import com.harris.gcsd.dex.jumpstart.GenericMessage;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.Map;

/**
 * Outputs message details to the console.
 */
public class LatencyOutput implements Output
{
    private static final String PRODUCER_TIMESTAMP = "JSKTimestamp";
    private static final String CONSUME_TIMESTAMP = "JSKConsume";

    private double theAverageLatency = 0;
    private static boolean theLatencyErrFlag = false;
    private static AtomicInteger theMessageCount = new AtomicInteger();
    private static AtomicLong theTotalLatency = new AtomicLong();
    private static AtomicLong theMaxLatency = new AtomicLong(Long.MIN_VALUE);
    private static AtomicLong theMinLatency = new AtomicLong(Long.MAX_VALUE);

    /**
     * Constructs a console output with the provided file.
     */
    public LatencyOutput()
    {

    }

    @Override
    public void onMessage(GenericMessage aMessage)
    {
        theMessageCount.getAndIncrement();
        Map<String, Object> messageProperties = aMessage.getProperties();

        long latency = 0;
        if (messageProperties.get(PRODUCER_TIMESTAMP) != null)
        {
            long producerTimestamp = Long.decode(messageProperties.get(PRODUCER_TIMESTAMP).toString());
            long consumerTimestamp = Long.decode(messageProperties.get(CONSUME_TIMESTAMP).toString());
            latency = consumerTimestamp - producerTimestamp;
            //Update the latency measurements
            theTotalLatency.getAndAdd(latency);
            theMaxLatency.accumulateAndGet(latency, Math::max);
            theMinLatency.accumulateAndGet(latency, Math::min);
        }
        else
        {
            theLatencyErrFlag = true;
        }
    }

    @Override
    public void finalOutput()
    {
        if (theLatencyErrFlag)
        {
            System.out.println("");
            System.out.println("Latency measurement was enabled but no latency timestamp was found on messages."
                + " Make sure that the latency flag (-l) is set on the producer.");
            System.out.println("");
        }
        else
        {
            if (theMessageCount.get() == 0)
            {
                theMaxLatency.set(0);
                theMinLatency.set(0);
                theAverageLatency = 0;
            }
            else
            {
                theAverageLatency = ((double) theTotalLatency.get() / (double) theMessageCount.get());
            }
            System.out.println("");
            System.out.println("Average message latency: " + theAverageLatency + " ms");
            System.out.println("Maximum message latency: " + theMaxLatency.get() + " ms");
            System.out.println("Minumum message latency: " + theMinLatency.get() + " ms");
            System.out.println("");
        }
    }
}
