/*******************************************************************************
 * Copyright (c) 2021 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jumpstart.output;

import com.harris.gcsd.dex.jumpstart.GenericMessage;

import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;


/**
 * Outputs message details to the console.
 */
public class ConsoleOutput implements Output
{
    // format for human readable dates
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.SSS");
    private static final String CONSUME_TIMESTAMP = "JSKConsume";
    private static final int OUTPUT_DEFAULT_LENGTH = 500;

    private static AtomicInteger theMessageCount = new AtomicInteger();

    @Override
    public void onMessage(GenericMessage aMessage)
    {
        long ttl = 0;
        StringBuilder outputString = new StringBuilder(OUTPUT_DEFAULT_LENGTH);

        Map<String, Object> properties = aMessage.getProperties();
        long consumeTime = Long.decode(properties.get(CONSUME_TIMESTAMP).toString());

        outputString.append("\n\n=== Received a message === \n");
        outputString.append("Time Consumed: " + DATE_FORMAT.format(consumeTime) +
            " Epoch: " + consumeTime + "\n");

        outputString.append(formatProperty("Destination", properties.get("JMS_Destination")));
        outputString.append(formatProperty("JMSDeliveryMode", properties.get("JMS_DeliveryMode")));
        outputString.append(formatProperty("JMSTimestamp", properties.get("JMS_Timestamp")));
        outputString.append(formatProperty("JMSExpiration", properties.get("JMS_Expiration")));
        outputString.append(formatProperty("JMSPriority", properties.get("JMS_Priority")));
        outputString.append(formatProperty("JMSCorrelationID", properties.get("JMS_CorrelationID")));

        outputString.append("Message Count: " + (theMessageCount.getAndIncrement() + 1) + "\n");

        for (String name : properties.keySet())
        {
            if (!name.startsWith("JMS_"))
            {
                outputString.append("Property name = " + name + "; value = " +
                    Objects.toString(properties.get(name), "") + "\n");
            }
        }

        try
        {
            ttl = Long.decode(properties.get("JMS_Expiration").toString()) -
            Long.decode(properties.get("JMS_Timestamp").toString());
            if (ttl < 0)
            {
                ttl = 0;
            }
            outputString.append("TimeToLive = " + ttl + "\n");
        }
        catch (Exception e)
        {
            outputString.append("TimeToLive could not be calcuated: " + e.getMessage() + "\n");
        }

        Object content = aMessage.getContent();
        if (content instanceof byte[])
        {
            byte[] messageBody = (byte[]) content;
            outputString.append("BytesMessage\n");
            outputString.append("Message length: " + messageBody.length + "\n");
            outputString.append("Received message: " + new String(messageBody) + "\n");
        }
        else if (content instanceof String)
        {
            outputString.append("TextMessage\n");
            outputString.append(content + "\n");
        }
        else
        {
            outputString.append("Unsupported message type: " + aMessage.getClass().getName() + "\n");
        }
        System.out.println(outputString.toString());
    }

    @Override
    public void finalOutput()
    {
        //Code to run on output close
    }

    /**
     * Format a property value.
     *
     * @param aName the property name
     * @param aValue the property value
     * @return the formatted property string
     */
    private String formatProperty(String aName, Object aValue)
    {
        if (aValue != null)
        {
            return aName + ": " + aValue.toString() + "\n";
        }
        return "";
    }
}
