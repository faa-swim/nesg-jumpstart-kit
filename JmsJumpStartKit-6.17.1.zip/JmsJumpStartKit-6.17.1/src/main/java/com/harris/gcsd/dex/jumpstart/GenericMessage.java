/*******************************************************************************
 * Copyright (c) 2021 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jumpstart;

import java.util.HashMap;
import java.util.Map;


/**
 * Object that represents a generic message.
 */
public class GenericMessage
{
    private Map<String, Object> theProperties;
    private Object theContent;

    /**
     * Default Constructor.
     */
    public GenericMessage()
    {
        theProperties = new HashMap<>();
    }

    /**
     * Construct a message with the message content.
     *
     * @param aContent the message content
     */
    public GenericMessage(Object aContent)
    {
        theContent = aContent;
    }

    /**
     * Construct a message with the message properties and the message content.
     *
     * @param aProperties the message properties
     * @param aContent the message content
     */
    public GenericMessage(Map<String, Object> aProperties, Object aContent)
    {
        this.theProperties = aProperties;
        this.theContent = aContent;
    }

    public Map<String, Object> getProperties()
    {
        return theProperties;
    }

    /**
     * Adds a property to the message.
     *
     * @param aName the name of the property
     * @param aValue the value of the property
     */
    public void addProperty(String aName, Object aValue)
    {
        if (theProperties == null)
        {
            theProperties = new HashMap<>();
            theProperties.put(aName, aValue);
        }
        else
        {
            theProperties.put(aName, aValue);
        }

    }

    public Object getContent()
    {
        return theContent;
    }

    /**
     * Returns the content as an instance of the given type
     *
     * @param aType the type to return
     * @param <T> the type to return
     * @return the content
     */
    public <T> T getContent(Class<T> aType)
    {
        return aType.cast(theContent);
    }

    public void setContent(Object aContent)
    {
        theContent = aContent;
    }
}
