/*******************************************************************************
 * Copyright (c) 2021 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  s
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jumpstart.output;

import com.harris.gcsd.dex.jumpstart.FileUtil;
import com.harris.gcsd.dex.jumpstart.GenericMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;


/**
 * File output that writes property and content files to a directory. Each property and corresponding content file is
 * named the same. The properties file contains the message headers in java properties format and has a
 * file extension of .properties. Text content files can have an extension of either .xml for XML content or .txt for
 * non XML text content. Binary content files must have a file extension of .bytes If the message content is null a
 * content file is not written.
 */
public class FileOutput implements Output
{
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss");

    private static final Logger theLogger = LoggerFactory.getLogger(FileOutput.class);

    private File theOutputDirectory;

    /**
    * Constructs a file output with the provided directory.
    *
    * @param anOutputDirectory the directory to write files to
    */
    public FileOutput(String anOutputDirectory)
    {
        theOutputDirectory = new File(anOutputDirectory);

        if (!theOutputDirectory.isDirectory())
        {
            throw new IllegalArgumentException();
        }
    }

    @Override
    public void onMessage(GenericMessage aMessage)
    {
        try
        {
            Map<String, Object> properties = aMessage.getProperties();
            String fileName;

            if (properties.get("filename") != null)
            {
                fileName = String.valueOf(properties.get("filename"));
            }
            else
            {
                fileName = DATE_FORMAT.format(System.currentTimeMillis()) + "-" + UUID.randomUUID().toString();
            }

            try (OutputStream outputStream = new FileOutputStream(new File(theOutputDirectory, fileName +
                ".properties")))
            {
                Properties props = new Properties();

                for (Map.Entry<String, Object> entry : properties.entrySet())
                {
                    props.put(entry.getKey(), String.valueOf(entry.getValue()));
                }

                props.store(outputStream, null);
            }

            if (aMessage.getContent() != null)
            {

                if (aMessage.getContent() instanceof byte[])
                {
                    FileUtil.writeBytes(new File(theOutputDirectory, fileName + ".bytes"),
                        (byte[]) aMessage.getContent());
                }
                else if (FileUtil.isXml((String) aMessage.getContent()))
                {
                    //TODO XML
                    FileUtil.writeText(new File(theOutputDirectory, fileName + ".xml"), (String) aMessage.getContent());
                }
                else if (aMessage.getContent() instanceof String)
                {
                    FileUtil.writeText(new File(theOutputDirectory, fileName + ".txt"), (String) aMessage.getContent());
                }
            }
        }
        catch (Exception e)
        {
            theLogger.warn("Could not write message due to: {}", e.getMessage(), e);
        }
    }

    @Override
    public void finalOutput()
    {
        //Code to run on output close
    }
}
