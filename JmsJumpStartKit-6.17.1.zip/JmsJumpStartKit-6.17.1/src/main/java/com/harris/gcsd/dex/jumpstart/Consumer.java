/*******************************************************************************
 * Copyright (c) 2021 - 2024 L3Harris Technologies
 * 
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *******************************************************************************/

package com.harris.gcsd.dex.jumpstart;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.harris.gcsd.dex.jmsclient.JmsClientConfiguration;
import com.harris.gcsd.dex.jmsclient.JmsConsumer;
import com.harris.gcsd.dex.jumpstart.output.FileOutput;
import com.harris.gcsd.dex.jumpstart.output.Output;
import com.harris.gcsd.dex.jumpstart.output.ConsoleOutput;
import com.harris.gcsd.dex.jumpstart.output.LatencyOutput;
import com.harris.gcsd.dex.jumpstart.output.XMLValidationConsoleOutput;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import javax.jms.Message;
import javax.jms.MessageListener;

/**
 * JMS consumer implementation.
 */
public class Consumer implements AutoCloseable, MessageListener, Runnable
{
    private static final Options OPTIONS = getOptions();
    private static final String DEFAULT_PROPERTIES_FILE = "../conf/consumer.properties";

    private static final String MESSAGE_LATENCY = "Message Latency";

    protected static int theConsumerNumber = 1;
    private static int theProcessNumber = 1;

    private List<Output> theOutputs;
    private JmsClientConfiguration theJmsConfiguration;
    private JmsConsumer theJmsConsumer;
    private int theConsumerMessages = 0;
    private ExecutorService theExecutor;

    //vars for latency measurements
    private boolean theMeasureLatency = false;
    private boolean theLatencyErrFlag = false;
    private long theTotalLatency = 0;
    private double theAverageLatency = 0;
    private long theMaxLatency = Long.MIN_VALUE;
    private long theMinLatency = Long.MAX_VALUE;

    //vars for transactions
    private long theTransactionCounter = 1;
    private long theTransactionLimit = 1;

    /**
     * Constructor that creates a consumer from the command line args
     *
     * @param anArgs the args
     */
    public Consumer(String[] anArgs)
    {
        parseArgs(anArgs);
        theJmsConsumer = new JmsConsumer(theJmsConfiguration, this);
        theExecutor = Executors.newFixedThreadPool(theProcessNumber);
        if (theJmsConfiguration.getIsTransacted())
        {
            if (theJmsConfiguration.getTransactionLimit() > 0)
            {
                theTransactionLimit = theJmsConfiguration.getTransactionLimit();
            }
        }
    }

    @Override
    public void run()
    {
        try
        {
            theJmsConsumer.connect();
            System.out.println("Consumer consuming from: " + theJmsConfiguration.getDestinationName());
            System.out.println("Consumer started waiting for messages...");
        }
        catch (Exception e)
        {
            if (e.getMessage() != null)
            {
                throw new RuntimeException("Exception while connecting: " + e.getMessage(), e);
            }
             else 
            {
                throw new RuntimeException("RootException while connecting: " + e.getCause().getMessage(), e);
            }
        }
    }

    @Override
    public void onMessage(Message aMessage)
    {
        theConsumerMessages += 1;
        if (theJmsConfiguration.getIsTransacted())
        {
            if (theTransactionCounter >= theTransactionLimit)
            {
                theJmsConsumer.commit();
                theTransactionCounter = 1;
            }
            else
            {
                theTransactionCounter++;
            }

        }

        theExecutor.execute(new ConsumerMessageProcessor(aMessage, theOutputs, theMeasureLatency));
    }

    @Override
    public void close()
    {
        if (theJmsConsumer != null)
        {
            if (theJmsConfiguration.getIsTransacted())
            {
                theJmsConsumer.rollback();
                System.out.println("The transaction was rolled back.");
            }
            theJmsConsumer.close();
        }
        if (theExecutor != null)
        {
            theExecutor.shutdown();
        }
    }

    /**
     * Parses the args for a consumer.
     *
     * @param anArgs the command line args
     */
    private void parseArgs(String[] anArgs)
    {
        theOutputs = new ArrayList<>();
        String currentParse = "";

        try
        {
            CommandLineParser parser = new DefaultParser();
            CommandLine line = parser.parse(OPTIONS, anArgs);

            if (line.hasOption('h'))
            {
                currentParse = "-h";
                printUsage();
                System.exit(0);
            }

            String propertiesFile = DEFAULT_PROPERTIES_FILE;

            if (line.hasOption("pf"))
            {
                currentParse = "-pf";
                propertiesFile = line.getOptionValue("pf").trim();
            }

            theJmsConfiguration = new JmsClientConfiguration(propertiesFile);

            if (line.hasOption("pn"))
            {
                theProcessNumber = Integer.parseInt(line.getOptionValue("pn").trim());
            }

            if (line.hasOption('d'))
            {
                currentParse = "-d";
                theOutputs.add(new FileOutput(line.getOptionValue('d').trim()));
            }

            if (!line.hasOption("nc"))
            {
                currentParse = "-nc";
                theOutputs.add(new ConsoleOutput());
            }

            if (line.hasOption("l"))
            {
                theMeasureLatency = true;
                theOutputs.add(new LatencyOutput());
            }

            if (line.hasOption("sf"))
            {
                currentParse = "-sf";
                theOutputs.add(new XMLValidationConsoleOutput(line.getOptionValue("sf").trim()));
            }

        }
        catch (Exception e)
        {
            throw new RuntimeException("Parsing failed on " + currentParse + ". Reason: " + e.getMessage());
        }
    }

    /**
     * Parses the args for the consumer group.
     *
     * @param anArgs the command line args
     */
    protected static void parseCommandArgs(String[] anArgs)
    {
        try
        {
            CommandLineParser parser = new DefaultParser();
            CommandLine line = parser.parse(OPTIONS, anArgs);

            if (line.hasOption("c"))
            {
                theConsumerNumber = Integer.parseInt(line.getOptionValue("c").trim());
            }
        }
        catch (Exception e)
        {
            throw new RuntimeException("Parsing failed. Reason: " + e.getMessage());
        }
    }

    /**
     * Creates the Options object.
     *
     * @return the options
     */
    private static Options getOptions()
    {
        Options options = new Options();
        options.addOption(Option.builder("c").longOpt("consumer_number").hasArg().
            desc("Overrides the default number of consumers to create").build());
        options.addOption(Option.builder("d").longOpt("directory").hasArg().
            desc("Directory to output messages to").build());
        options.addOption(Option.builder("h").longOpt("help").desc("Print this message").build());
        options.addOption(Option.builder("l").longOpt("latency").
            desc("Calculates message latency. Latency flag must be set on producer.").build());
        options.addOption(Option.builder("nc").longOpt("no_console").
            desc("Disables outputting messages to console").build());
        options.addOption(Option.builder("pf").longOpt("property_file").hasArg().
            desc("Overrides the default properties file location").build());
        options.addOption(Option.builder("pn").longOpt("process_number").hasArg().
            desc("Overrides the default number of message processors").build());
        options.addOption(Option.builder("sf").longOpt("schema_file").hasArg().
            desc("Path to the xml schema file. Enables xml validation.").build());
        return options;
    }

    /**
     * Gets the outputs of a consumer.
     *
     * @return the outputs
     */
    public List<Output> getOutputs()
    {
        return theOutputs;
    }

    /**
     * Adds an output to a consumer.
     *
     * @param aOutput the output to add.
     */
    public void addOutput(Output aOutput)
    {
        theOutputs.add(aOutput);
    }

    /**
     * Prints the usage statement.
     */
    private static void printUsage()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.printHelp("consumer", OPTIONS, true);
    }

    /**
     * Prints the number of messages received.
     * @param aConsumerNum the consumer number.
     * @return the number of messages
     */
    public int printTotalMessages(int aConsumerNum)
    {
        System.out.println("");
        System.out.println("Consumer was consuming from: " + theJmsConfiguration.getDestinationName());
        System.out.println("Consumer " + aConsumerNum + " total messages: " + theConsumerMessages);
        System.out.println("");

        return theConsumerMessages;
    }

    /**
     * Creates a consumer and begins consuming.
     *
     * @param args
     *           The command line arguments. The first command line input is used
     *           to find the connection properties file
     */
    public static void main(String[] args)
    {
        final Thread mainThread = Thread.currentThread();
        final CountDownLatch latch = new CountDownLatch(1);
        ArrayList<Consumer> consumerList = new ArrayList<Consumer>();
        parseCommandArgs(args);

        for (int i = 0; i < theConsumerNumber; i++)
        {
            try
            {
                Consumer consumer = new Consumer(args);
                consumer.run();
                consumerList.add(consumer);
            }
            catch (Exception e)
            {
                System.err.println(e.getMessage());
                e.printStackTrace();
                System.exit(1);
            }
        }
        System.out.println("\nAll consumers started, waiting for messages...");
        try
        {
            Runtime.getRuntime().addShutdownHook(new Thread()
            {
                public void run()
                {
                    System.out.println("Process has been shut down externally");
                    List<Output> outputs = new ArrayList<>();
                    int total = 0;
                    for (int i = 0; i < theConsumerNumber; i++)
                    {
                        Consumer consumer = consumerList.get(i);
                        consumer.close();
                        total += consumer.printTotalMessages(i + 1);
                        outputs = consumer.getOutputs();
                    }

                    for (Output output : outputs)
                    {
                        output.finalOutput();
                    }

                    System.out.println("");
                    System.out.println("Total messages: " + total);
                    System.out.println("");
                }
            });
            try
            {
                latch.await();
            }
            catch (InterruptedException e)
            {
                //Do Nothing
            }
            System.exit(0);
        }
        catch (Exception e)
        {
            System.err.println("");
            e.printStackTrace();
            System.exit(1);
        }
    }
}
