# Quick Start Guide #

This is a guide to get the NEMS JumpstartKit up and running quickly.

The first step is to unzip the JumpstartKit zip file to a folder you would like to keep it in. Next, follow the steps below depending on what you want to do.

## Starting a producer ##

### Using the script ###

1. Navigate to the conf folder in the JumpstartKit.
2. Open the producer.properties file.
3. Uncomment and edit the appropriate properties for what you would like to producer to. (Refer to the section below for more information)
4. Save and close the file.
5. Navigate to the bin folder in the JumpstartKit.
6. From the console, execute the appropriate producer script for your operating system. (./producer.bat for Windows. ./producer.sh for Linux)

### Editing the properties ###

Instructions on how to edit the broker sections in the properties file.

#### Solace Section ####

Uncomment these properties in the solace section of the config file:
- jndi.context.factory
- jndi.provider.url=smf://hostname
- solace.vpn
- auth.type=BASIC
- username
- password
- connection.factory
- destination.name
- destination.type

Fill out the hostname, vpn, username, password, connection factory, and destination name. Once that is done, continue to step 4 above.

If you would like to use certificate authentication, TLS, or topic producing, information on these can be found in the Usage Guide document.

#### ActiveMQ Section ####

Uncomment these properties in the activeMQ section of the config file:
- jndi.context.factory
- jndi.provider.url=nio://hostname:61616
- username
- password
- connection.factory
- destination.name

Fill out the hostname, username, password, connection factory, and destination name. Once that is done, continue to step 4 above.

If you would like to use TLS, information on this can be found in the Usage Guide document.

#### WLS Section ####

Uncomment these properties in the WLS section of the config file:
- jndi.context.factory
- jndi.provider.url
- username
- password
- connection.factory
- destination.name

Fill out the hostnames, username, password, connection factory, and destination name. Once that is done, continue to step 4 above.

## Starting a consumer ##
1. Navigate to the conf folder in the JumpstartKit.
2. Open the consumer.properties file.
3. Uncomment and edit the appropriate properties for what you would like to consume from. (Refer to the section below for more information)
4. Save and close the file.
5. Navigate to the bin folder in the JumpstartKit.
6. From the console, execute the appropriate producer script for your operating system. (./consumer.bat for Windows. ./consumer.sh for Linux)

### Editing the properties ###

Instructions on how to edit the broker sections in the properties file.

#### Solace Section ####

Uncomment these properties in the solace section of the config file:
- jndi.context.factory
- jndi.provider.url=smf://hostname
- solace.vpn
- auth.type=BASIC
- username
- password
- connection.factory
- destination.name

Fill out the hostname, vpn, username, password, connection factory, and destination name. Once that is done, continue to step 4 above.

If you would like to use certificate authentication or TLS, information on these can be found in the Usage Guide document.

#### ActiveMQ Section ####

Uncomment these properties in the activeMQ section of the config file:
- jndi.context.factory
- jndi.provider.url=nio://hostname:61616
- username
- password
- connection.factory
- destination.name

Fill out the hostname, username, password, connection factory, and destination name. Once that is done, continue to step 4 above.

If you would like to use TLS, information on this can be found in the Usage Guide document.

#### WLS Section ####

Uncomment these properties in the WLS section of the config file:
- jndi.context.factory
- jndi.provider.url
- username
- password
- connection.factory
- destination.name

Fill out the hostnames, username, password, connection factory, and destination name. Once that is done, continue to step 4 above.
