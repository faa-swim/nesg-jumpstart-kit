# Development Overview #

## Structure ##

The jumpstart kit has three components: JmsClient, JmsJumpStartKit, and JumpStartKitCommon.

### JmsClient ###

The JmsClient section contains the java files that create the JMS connection. The abstract class, `JmsClient.java`, is a class used by both JmsConsumer.java and JmsProducer.java. These three classes help start the JMS connection, stop the connection, receive messages, and send messages. The fourth file in this section is JmsClientConfiguration.java, which handles processing the properties for the JmsClients. If you want to add features related the JMS connection, this section would be the place to add it to.

### JmsJumpStartKit ###

The JmsJumpStartKit section contains the scripts, properties, and main java files. The script files are the bash and bat files that start the jumpstart kit. The properties files contain the connection information for the consumers or producers. The main java files are the java files that manages the sending and received of messages by using all the other java files. This is also where the multi-threading logic is located for the producers and consumers. If you want to add more CLI flags or you added a feature to another section, this is where it would be implemented.

### JumpStartKitCommon ###

The JumpStartKitCommon section contains java files for input, output, and utility. The input files are the way the JSK gets the next message to send and must implement the Input.java interface. The output files are how the JSK processes the received messages and must implement the Output.java interface. If an input or output is added, it needs to be added to the main java files in the JmsJumpStartKit section. The rest of the files in this section are utility files.

## Adding inputs and outputs ##

### Inputs ###

1. Create a class that implements the input.java interface.
2. Place the java file in the input folder in the JumpStartKitCommon section.
3. Open the Producer.java file in the JmsJumpStartKit section.
4. Import the new input class.
5. Create a new flag in the parseArgs method.
6. In the new flag section, set an instance of the class equal to the variable theInput.

### Outputs ###

1. Create a class that implements the output.java interface.
2. Place the java file in the output folder in the JumpStartKitCommon section.
3. Open the Consumer.java file in the JmsJumpStartKit section.
4. Import the new output class.
5. Create a new flag in the parseArgs method.
6. In the new flag section, add an instance of the class to the list theOutputs.