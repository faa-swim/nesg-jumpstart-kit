# Changelog

### 6.17.1 - 28 Apr 2025
- *DEXSW-8784 / 8810 / 8814*
- Added WebLogicJMSUtilities-1.1.2 to JmsJumpStartKit.
- Fixed persistent producer ignoring Persistent setting on ConnectionFactory
- Changed documentation pdf to html

### 6.17.0 - 02 Apr 2025
- *DEXSW-8678*
- Updated JmsJumpStartKit wlthint3client version to 14.1.1.
- Updated JmsJumpStartKit sol-jms version to 10.26.0.

### 6.16.0 - 03 Mar 2025
- *DEXSW-8602*
- Updated JmsJumpStartKit sol-jms version to 10.10.2.

### 6.15.0 - 10 Oct 2024
- *DEXSW-6764 / 7797*
- Fixed contextFactory.
- Fixed incorrect null pointers in errors. 
- Packaged log4j2, removed log4j.
- Added changelog.
- Revised readme and guides. 

### 6.14.0 - 08 Mar 2023
- *DEXSW-6631 / 6663 / 6682*
- Overhauled message rate calculations for better accuracy and stability. 
- Added support for decimal message rates, including below one. 
- Added support for DUPS property in JMS. 

### 6.13.0 - 14 Feb 2023
- *DEXSW-6642*
- Added dead message queue option. 

### 6.12.0 - 26 Jan 2023
- *DEXSW-6229*
- Added support for bytes messages. 

### 6.11.0 - 03 Oct 2022
- *DEXSW-6481 / 6482 / 6493*
- Added LMR test client.
- Added interrupt logic to allow producer to finish sending and update statistics.
- Changed formatting in some console prints.
- Added connection retry counts and intervals to properties files. 

### 6.10.2 - 24 Jun 2022
- *DEXTST-290*
- Fixed amq producer failover.

### 6.10.1 - 14 Feb 2022
- *DEXSW-6292*
- Updated log4j to address security vulnerability CVE-2021-44832.

### 6.10.0 - 12 Oct 2021
- *DEXSW-5700 / 6191*
- Removed 12k message limit from JSK.
- Revised copyright headers.

### 6.9.0 - 30 Apr 2020
- *DEXSW-5516*
- Added support for standard JMS transactions when consuming from solace. 

### 6.8.1 - 06 Mar 2020
- *DEXSW-5464*
- Added documentation and reduced the default message rate/number. 

### 6.8.0 - 13 Feb 2020
- *DEXSW-5370*
- Added multi threading producing and recreated the batching method. 

### 6.7.0 - 04 Dec 2019	
- *DEXSW-5336*
- Added the TTL, delivery mode, and priority flags for the producer 

### 6.6.0 - 05 Nov 2019
- *DEXSW-4789 / 4790 / 4945*
- Added schema validation option for consuming XML content. 
- Added multi-threaded consumer creation.
- Improved error checking / output. 

### 6.5.0 - 17 Sep 2019
- *DEXSW-5109 / 5126*
- Updated the JSK to send messages in batches.
- Added units to latency measurements. 
- Changed flag to disable console output.

### 6.4.0 - 05 Sep 2019
- *DEXSW-5072*
- Added Latency measurement option. 
- Added SSL downgrade options. 

### 6.3.0 - 30 Jul 2019
- *DEXSW-4788 / 4934 / 5031*
- Added file output if XML is detected.
- Fixed SimpleErrorHanler logging.
- Added total message count to consumer.
- Added fixed message count in producer.
- Fixed forward slashes being removed from loaded property files.

### 6.2.0 - 17 Jul 2019
- *DEXSW-5028*
- Updated the consumer to close when the script is stopped. 

### 6.1.0 - 06 Jun 2019
- *DEXSW-4948*
- Added message rate option to producer. 
- Added message count to consumer. 

### 6.0.0 - 29 May 2019
- *DEXSW-5022* 
- Initial Commit. 
- Added initial usage guide with TLS, compression, encryption, and latency calculations.