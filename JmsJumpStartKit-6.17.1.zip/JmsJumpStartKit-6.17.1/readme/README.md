# NEMS JumpStartKit
The JumpStartKit is a set of tools that allow testing of JMS routes / queues / topics. 

Producer and Consumer connections to AMQ, WLS, and Solace are supported. 

There is also an NEMS LMR (Lost Message Retrieval) test script included. 

# Documentation
- **[Quick Start Guide](QuickStart.md)** - Overview on how to quickly begin using the JSK.
- **[Usage Guide](UsageGuide.md)** - Detailed instructions on how to use the JMS JumpStartKit.
- **[Changelog](Changelog.md)**

