# Usage Guide #

#### Index: ####

* [README Home](README.md)

## Command Line Arguments ##

Here is a list of optional arguments that can be set while calling the script. These can also be seen by using the -h flag.

### Producer ###

* __-d, --directory__ <*DIRECTORY*>

    * The directory to load messages from. Overrides the --message flag.
    * *DIRECTORY* can be the absolute path or the relative path from the script.
    * The message files must have the file extension .xml, .txt. or .bytes. There must also be a .properties file for each message file and has the same name.

* __-dm, --delivery_mode__ <*DM*>

    * Overrides the default delivery mode, which is 1.
    * *DM* can be either 1 (non_persistent) or 2 (persistent)

* __-dmq, --dead_message_queue__ <*DMQ*>

    * Sets the Solace dead message queue header with a boolean type.
    * *DMQ* can be either set as `true` (enabled) or `false` (disabled)

* __-h, --help__

    * Prints the help message.

* __-l, --latency__

    * Adds a timestamp to the message header to calculate latency.
    * Must have the latency flag enabled on the consumer to view the latency.

* __-m, --message__ <*MESSAGE*>

    * Sets the body of the message to *MESSAGE*. Conflicts with the --directory flag.

* __-mn, --message_number__ <*MN*>

    * The total number of messages to produce. 

* __-mr, --message_rate__ <*MR*>

    * The rate to produce messages in messages per second.

* __-pf, --property_file__ <*PF*>

    * Loads the property file *PF* instead of the default property file *producer.properties*.

* __-pn, --producer_number__ <*PN*>

    * Overrides the default number of producers, which is 1.
    * Each producer will produce at a rate of (*message_rate* divided by *producer_number*).
    * Each producer will produce about (*message_number* divided by *producer_number*) messages

* __-pr, --priority__ <*PR*>

    * Overrides the default priority, which is 4.
    * *PR* is a number ranging from 0 (lowest priority) to 9 (highest priority)

* __-ttl, --time_to_live__ <*TTL*>

    * Overrides the default time to live in milliseconds, which is 0 (never expires).

### Producer Examples ###

Example 1:  
`./producer.sh`  
Run the script using the default property file and send the default message "Test Message" at 1 message per second, one time.

Example 2:  
`./producer.sh -pf ../conf/test.properties -mr 5 -mn 80 -m "Hello World"`  
Runs the script using the test.properties file located in the conf directory, in the parent folder. The body of the message contains "Hello World" and is sent at 5 messages per second for 16 seconds, which is 80 total messages.

Example 3:  
`./producer.sh -pf ../conf/test.properties -mr 5 -mn 80 -d ../data/testMessages`  
Runs the script the same as the example above except the messages are now loaded from the testMessages folder found in the data directory. The message being sent will rotate between each message file pair in the folder. 80 messages are sent at 5 per second.

Example 4:  
`./producer.sh -pf ../conf/test.properties -dm 2 -pn 10 -l -mn 280 -mr 20`  
Runs the script using the test.properties file. The messages are set to persistent and the latency header is added to all messages. 10 producers will be sending 2 message per second each for 14 seconds, which is 280 total messages.

Example 5:  
`./producer.sh -mn 200 -ttl 4000 -pr 6`  
Runs the script using the default properties file. 200 messages are sent at 1 message per second, and each message has a TTL of 4 seconds and a priority of 6.


### Consumer ###

* __-c, --consumer_number__ <*C*>

    * Overrides the default number of consumers to create, which is 1.

* __-d, --directory__ <*DIRECTORY*>

    * The directory to output messages to.
    * *DIRECTORY* can be the absolute path or the relative path from the script.

* __-h, --help__

    * Prints the help message.

* __-nc, --no_console__

    * Disables outputting messages to console.

* __-l, --latency__

    * Calculates the message latency.
    * Must have the latency flag enabled on the producer to view the latency.

* __-pf, --property_file__ <*PF*>

    * Loads the property file *PF* instead of the default property file *producer.properties*.

* __-pn, --process_number__ <*PN*>

    * Overrides the default number of message processors per consumer, which is 1.

* __-sf, --schema_file__ <*SF*>

    * Path to the xml schema file. Enables xml validation.
    * *SF* can be the absolute path or the relative path from the script.

### Consumer Examples ###

Example 1:  
`consumer.sh`  
Runs the script using the default property file. 1 consumer will connect and consumed messages are printed to the screen.

Example 2:  
`./consumer.sh -pf ../conf/test.properties -c 5 -pn 2 -nc`  
Runs the script using the test.properties file located in the conf directory, in the parent folder. 5 consumers will connect with 2 message processors each, for a total of 10 message processors. Message are not printed to the screen.

Example 3:  
`./consumer.sh -pf ../conf/test.properties -nc -d ../data/consumedMessages`  
Runs the script using the test.properties file located in the conf directory, in the parent folder. 1 consumer will connect and message are not printed to the screen. Messages are saved in the consumedMessages directory in data folder. 

Example 4:  
`./producer.sh -pf ../conf/test.properties -sf ../conf/schema.xml -l`  
Runs the script using the default property file. 1 consumer will connect and consumed messages are printed to the screen. The consumed messages will be checked against the schema file and the latency will be calculated.


## Property Files ##

### Editing the producer properties ###

Instructions on how to edit the broker sections in the producer properties file.

#### Solace Section ####

Uncomment these properties in the solace section of the config file and update every value in angle brackets:
```properties
jndi.context.factory=com.solacesystems.jndi.SolJNDIInitialContextFactory
jndi.provider.url=smf://<hostname>
solace.vpn=<vpn>
auth.type=BASIC
username=<user>
password=<password>
connection.factory=<ConnectionFactory.CF>
destination.name=<Queue.IN>
destination.type=jndi
```

If you would like to use certificate authentication or TLS, information on these can be found in the SSL/TLS section below.

##### Topic producing #####
To produce to a topic instead of a queue, set these headers and update the value in the angle brackets:
```properties
destination.name=<Topic/In>
destination.type=topic
```
You can also produce to a topic based off of the headers in a message by using a format string:
```properties
format.string=${DEX_SOURCE_TYPE}:${SOME_OTHER_HEADER}:${ANOTHER_HEADER}
```

Putting the properties *DEX_SOURCE_TYPE=TEST*, *SOME_OTHER_HEADER=TOPIC*, and *ANOTHER_HEADER=THREE* into the header file of a message would send the message to the topic TEST/TOPIC/THREE. Using the format.string will override the destination.name property.

#### ActiveMQ Section ####

Uncomment these properties in the activeMQ section of the config file and update every value in angle brackets:
```properties
- jndi.context.factory=org.apache.activemq.jndi.ActiveMQInitialContextFactory
- jndi.provider.url=failover(tcp://<hostname1>:61616,tcp://<hostname2>:61616,tcp://<hostname3>:61616)?maxReconnectAttempts=0
- username=<user>
- password=<password>
- connection.factory=ConnectionFactory
- destination.name=<dynamicQueues/Queue.IN>
```

If you would like to use TLS, information on this can be found in the SSL/TLS section below.

#### WLS Section ####

Uncomment these properties in the WLS section of the config file and update every value in angle brackets:
```properties
jndi.context.factory=weblogic.jndi.WLInitialContextFactory
jndi.provider.url=t3://<hostname1>:8001,<hostname2>:8001,<hostname3>:8001
username=<user>
password=<password>
connection.factory=<ConnectionFactory.CF>
destination.name=<Queue.IN>
```

### Editing the consumer properties ###

Instructions on how to edit the broker sections in the consumer properties file.

#### Solace Section ####

Uncomment these properties in the solace section of the config file and update every value in angle brackets:
```properties
jndi.context.factory=com.solacesystems.jndi.SolJNDIInitialContextFactory
jndi.provider.url=smf://<hostname>
solace.vpn=<vpn>
auth.type=BASIC
username=<user>
password=<password>
connection.factory=<ConnectionFactory.CF>
destination.name=<Queue.IN>
```

If you would like to use certificate authentication or TLS, information on these can be found in the SSL/TLS section below.

#### ActiveMQ Section ####

Uncomment these properties in the activeMQ section of the config file and update every value in angle brackets:
```properties
jndi.context.factory=org.apache.activemq.jndi.ActiveMQInitialContextFactory
jndi.provider.url=nio://<hostname>:61616
username=<user>
password=<password>
connection.factory=ConnectionFactory
destination.name=<dynamicQueues/Queue.IN>
```

If you would like to use TLS, information on this can be found in the SSL/TLS section below.

#### WLS Section ####

Uncomment these properties in the WLS section of the config file and update every value in angle brackets:
```properties
jndi.context.factory=weblogic.jndi.WLInitialContextFactory
jndi.provider.url=t3://<hostname1>:8001,<hostname2>:8001,<hostname3>:8001
username=<user>
password=<password>
connection.factory=<ConnectionFactory.CF>
destination.name=<Queue.IN>
```

## Using SSL/TLS ##

Currently, NEMS supports the use of SSL/TLSv1.2 to publish/consume with AMQ or Solace.

### Requirements ###

1. A completed E5 order onramp. Contact your SWIM PMO representative if one has not been completed.
2. TLS ports open between the client server and the DMN (61617 - Talend) or Solace router (55443).
3. TLS configured for Talend or the Solace router, including all required server certs. 
4. The appropriate client certs to connect with. The Common Name (CN) in the cert must match the CN entry of the user on the LDAP.
5. JMSJumpstartKit-6.4.0 or higher.

#### Producer/Consumer Configuration ####

Setup your producer configuration as usual with the following changes:

#### Solace ####

* Set the provider URL to use the secure protocol

```properties
jndi.provider.url=smfs://<hostname>
```

* Change the authentication type to use client certificate

```properties
auth.type=CLIENT_CERTIFICATE
```

#### ActiveMQ ####

* Set the provider URL to use the secure protocol

```properties
jndi.provider.url=failover(ssl://<hostname1>:61617,ssl://<hostname2>:61617,ssl://<hostname3>:61617)?maxReconnectAttempts=0
```

#### TLS Configuration ####

* Set the keystore and truststore files and credentials. Default keystore we use is JKS, do not change unless necessary. For example purposes, we'll use STDDS E5 users here:

```properties
keystore.file=/opt/dex/certs/stdds/stdss_mco.jks

keystore.password=harris

#keystore.type=JKS

truststore.file=/opt/dex/certs/truststore.jks

truststore.password=harris

#truststore.type=JKS
```

#### Solace Encryption ####

With TLS enabled, Solace allows you to use client authentication encryption, and message traffic encryption. By default, both of these are enabled when using TLS. We are able to use unencrypted message traffic and only encrypted authentication by enabling SSL Downgrade. On your producer properties, set the SSL Downgrade property to "true"

```properties
enable.ssl.downgrade=true
```